# tinymce-plugin-build-v5
tinymce-plugin-v5
