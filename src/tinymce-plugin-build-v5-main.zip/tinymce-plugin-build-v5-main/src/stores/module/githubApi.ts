import { defineStore } from 'pinia'
import { http } from "../../../tools/http";
import { reactive, Ref, ref, toRef, toRefs } from 'vue'
import api from '/@/api';
const GlobalApi = {
  github:{
    api: "https://api.github.com",
    org: "tinymce-plugin"
    // org: "vuejs"
  },
  gitee:{
    api: "https://api.github.com",
    org: "tinymce-plugin"
  },
  jsdelivrApi: "https://cdn.jsdelivr.net/gh/tinymce-plugin"
}
const useGithubStore = defineStore({
  id: 'githubApi',
  state: () => ({
   
  }),
  actions: {
     /**
      *
      * 获取siteMap
      * @return {*} 
      */
      async getSiteMap(): Promise<any>{
        const resData:any = await http.request("get", `/siteMap.json`);
        return resData||{}
       },
     ...api
  }
})

export {
  useGithubStore,
}

// if (import.meta.hot) {
//   import.meta.hot.accept(acceptHMRUpdate(mainStore, import.meta.hot))
// }
