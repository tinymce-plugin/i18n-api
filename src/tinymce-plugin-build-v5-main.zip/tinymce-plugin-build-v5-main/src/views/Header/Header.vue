<template>
<div style="height: 152px"></div>
<div class="header-box" :class="[ IsFixed ? 'IsFixed' :'', dWidth<=750? 'IsMobile':'']">
<div class="header-search-Box">
   <search-box/>
</div>
<div class="header-centent">
 <h1 class="header-box_logo" >
    <span class="tinymce_color">Tinymce</span>
    <span class="header_logo" @click.stop="resetPola"> 
    <svg class="icon" id="logoSvgId"  viewBox="0 0 1024 1024"  :style="{top: polaTop+'px'}"  version="1.1" xmlns="http://www.w3.org/2000/svg"  p-id="5863" width="120" height="120">
        <path  transform="translate(868,2070) scale(2.1,2.1) rotate(180)" fill="none"  fill-opacity='null' stroke-opacity="null" stroke-width="16"  stroke="#335FFF"  d="m203.108398,645.3192c33.99355,0.20039 67.58717,28.4558 67.58717,69.63654c0,0 0.22086,11.0003 0.23698,24.09619l0.00048,2.53102c-0.0025,2.83556 -0.0155,5.74026 -0.04309,8.62832l-0.01835,1.73016c-0.12767,10.93632 -0.47796,21.38476 -1.27581,26.63907c-4.69911,31.46169 -28.19465,53.20432 -60.5885,58.71512c-29.19446,5.7112 -46.49118,9.01769 -52.09012,10.11985c-1.41149,0.29469 -5.65982,0.90142 -9.85524,1.35111l-0.83752,0.08771c-2.6445,0.27022 -5.1905,0.46491 -6.9039,0.46491c-35.59324,0 -67.88711,-26.65226 -68.38702,-69.63654l0.00088,-2.15162c0.00007,-0.10585 0.00014,-0.21526 0.00022,-0.32814l0.00086,-1.10755c0.00451,-5.18721 0.01936,-15.29461 0.06827,-25.59709l0.01191,-2.3788l0,0l0.00864,-1.58335c0.05803,-10.27482 0.15317,-20.13893 0.30914,-24.8672c1.19978,-31.3615 22.89566,-56.7112 64.18782,-64.82712l0.0598,-0.01163c1.94046,-0.37737 50.47261,-9.81564 52.53022,-10.20841c4.79909,-0.90176 10.09809,-1.30255 14.99716,-1.30255zm23.79548,36.57171l-79.98482,15.53045l0,31.2613l-31.99393,6.21218l0,77.95285l79.98482,-15.53046l0,-31.26129l31.99393,-6.21218l0,-77.95285zm-31.99393,37.47348l0,46.69155l-47.99089,9.31827l0,-46.69155l47.99089,-9.31827z" />
        <path id="logoSvgBottom" fill="#34435C"  transform="translate(-100,-100) scale(1.1,1.1)"  fill-opacity='0.75' stroke-opacity="null" stroke-width="32"  stroke="#34435C" d="M547.0208 823.650987L301.615787 681.970347V398.677333l245.405013-141.748906L792.41216 398.677333v283.293014z" ></path>
        <path fill="none"  fill-opacity='null' stroke-opacity="null" stroke-width="24"  stroke="#43B984" transform="translate(-26,-36) scale(1.03,1.03)" d="M782.595413 700.66176l-38.352213 22.1184a9.721173 9.721173 0 0 1-4.942507 1.365333 9.91232 9.91232 0 0 1-4.942506-18.445653l38.324906-22.145707a34.73408 34.73408 0 0 0 17.298774-29.969066v-281.258667a34.69312 34.69312 0 0 0-17.28512-29.928107l-243.698347-140.629333a34.638507 34.638507 0 0 0-34.583893 0L409.6 250.729813a46.789973 46.789973 0 0 1 2.402987 14.103894 47.786667 47.786667 0 1 1-12.151467-31.3344l84.650667-48.837974a54.613333 54.613333 0 0 1 54.381226 0l243.698347 140.629334a54.613333 54.613333 0 0 1 27.19744 47.076693v281.258667a54.504107 54.504107 0 0 1-27.183787 47.035733zM388.819627 251.849387a9.325227 9.325227 0 0 1-0.477867-0.873814 26.528427 26.528427 0 1 0 3.8912 13.871787 27.129173 27.129173 0 0 0-3.413333-12.997973z m350.467413 472.255146z m-105.417387-249.856c0-0.2048-0.12288-0.314027-0.12288-0.49152a9.079467 9.079467 0 0 1 2.49856-8.178346 8.533333 8.533333 0 0 1 3.76832-2.198187 8.833707 8.833707 0 0 1 9.161387 2.198187l48.16896 48.141653-3.467947 3.467947-57.01632 56.97536 1.59744-1.59744-13.653333-5.85728 55.391573-55.391574s-23.01952-23.497387-31.402666-31.402666c-3.085653-2.90816 5.802667 55.978667-47.14496 62.805333-28.808533 3.713707-54.463147-23.10144-55.00928-55.00928-0.65536-38.597973 51.6096-50.7904 47.14496-55.00928-23.688533-22.377813-55.00928-55.00928-55.00928-55.00928L397.312 519.099733l83.1488 78.52032-26.487467 26.46016a29.24544 29.24544 0 1 0 5.36576 5.69344h0.109227l26.70592-26.70592 52.578987 49.5616 86.016-86.016-7.468374 7.468374h19.510614l-99.669334 99.587413-51.336533-51.4048a9.106773 9.106773 0 0 0-15.428267 8.192c0 0.177493 0.095573 0.28672 0.095574 0.49152a4.696747 4.696747 0 0 0 0.77824 1.952427 39.594667 39.594667 0 1 1-23.552-23.770454 6.116693 6.116693 0 0 0 1.365333 0.505174 9.106773 9.106773 0 0 0 9.038507-15.209814l-77.4144-77.37344 65.672533-65.645226a9.106773 9.106773 0 0 0-8.27392-15.414614c-0.2048 0-0.28672 0.109227-0.49152 0.109227A4.724053 4.724053 0 0 0 435.541333 436.906667a39.594667 39.594667 0 1 1 23.784107-23.552 9.106773 9.106773 0 0 0 14.731947 10.349226l66.68288-66.64192 80.677546 80.636587a9.270613 9.270613 0 0 1 0 12.929707 9.106773 9.106773 0 0 1-9.024853 2.280106 4.096 4.096 0 0 1-1.365333-0.505173 39.471787 39.471787 0 0 0-41.7792 9.147733 39.594667 39.594667 0 1 0 65.37216 14.62272 5.188267 5.188267 0 0 1-0.764587-1.897813zM289.05472 320.279893l-38.352213 22.145707a34.69312 34.69312 0 0 0-17.230507 29.928107v281.258666a34.679467 34.679467 0 0 0 17.28512 29.914454l243.698347 140.629333a34.679467 34.679467 0 0 0 34.583893 0l84.759893-48.919893a46.803627 46.803627 0 0 1-2.389333-14.09024 47.786667 47.786667 0 1 1 12.151467 31.3344l-84.650667 48.837973a54.613333 54.613333 0 0 1-54.381227 0l-243.712-140.629333a54.490453 54.490453 0 0 1-27.19744-47.06304v-281.258667a54.613333 54.613333 0 0 1 27.19744-47.076693l38.324907-22.186667a9.898667 9.898667 0 1 1 9.91232 17.175893z m369.62304 468.309334a27.552427 27.552427 0 1 0-26.528427-27.470507 27.552427 27.552427 0 0 0 26.528427 27.52512z"></path>
    </svg>
    </span>
    <span class="line" :style="{width: 30+polaTop*1.2+'px'}">-</span>
    <span class="plugin_color">Plugin</span>
</h1>
<div class="content">
    <TPNavBarTranslations class="translations"/>
    <TPNavBarAppearance class="assppearance"/>
    <TPNavBarSocialLinks class="social-links"/>
    <TPNavBarExtra class="extra"/>
    <TPNavBarHamburger
          class="hamburger"
          :active="isScreenOpen"
          @click="toggleScreen"
        />
  
</div>
</div>
  <TPNavScreen :open="isScreenOpen"/>
</div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
// @ts-ignore
import Vivus from "../../assets/lib/vivus.js"
import { useNav } from '/@/composables/nav'

import TPNavBarAppearance from "/@/components/Appearance/TPNavBarAppearance.vue"
import TPNavBarTranslations from "/@/components/Translations/TPNavBarTranslations.vue"
import TPNavBarSocialLinks from "/@/components/SocialLinks/TPNavBarSocialLinks.vue"
import TPNavBarExtra from "/@/components/NavBarExtra/TPNavBarExtra.vue"
import TPNavScreen from '/@/components/NavScreen/TPNavScreen.vue'
import TPNavBarHamburger from '/@/components/NavScreen/TPNavBarHamburger.vue'
import SearchBox from "/@/views/Search/SearchBox.vue";
export default defineComponent({
    name: 'Header',
    components:{
        TPNavBarAppearance,
        TPNavBarTranslations,
        TPNavBarSocialLinks,
        TPNavBarExtra,
        TPNavScreen,
        TPNavBarHamburger,
        SearchBox
    },
    props:{
      dWidth: {
          type: Number,
          default: document.documentElement.clientWidth
      }
    },
    data(){
       return{
          pola: 2,
          polaTop: 0,
          scrolltop: document.documentElement.scrollTop,
          IsFixed: false,
          IsFixedM: false,
          IsMobile: false,
       }
    },
    setup(porps){
    const { isScreenOpen, closeScreen, toggleScreen } = useNav()
    return {
        isScreenOpen, closeScreen, toggleScreen
    }
    },
    created(){
        this.info()

    },
    mounted() {
    var that = this;
    window.onscroll = function(){
    //获取当前滚动条的位置
     that.scrolltop = document.documentElement.scrollTop;
     that.IsFixed = that.scrolltop >= 55 ? true : false;
     that.scrolltop < 55 && !that.IsFixed? that.polaTop = that.scrolltop: '';
     that.IsFixedM = that.scrolltop >= 1 ? true : false;
    }
   },
    methods:{
        info(){
           let that = this
           let intervalID =  setInterval(function(){
            if(document.getElementById('logoSvgId')){
                var timingProps = {
                type: 'scenario-sync',
                duration: 100,
                forceRender: false,
                pathTimingFunction: Vivus.EASE_IN,
                animatedTime: 80
                }; 
               that.pola = new Vivus('logoSvgId', timingProps);
               clearInterval(intervalID)
            }
            },200)
         
        },
        resetPola(){
           let that = this
             that.pola.play(-3)
            setTimeout(()=>{
             that.pola.reset().play()
            },1000)
        }
    }
})
</script>

<style lang="scss" scoped>

.header-box{
    border-bottom: 1px solid var(--tp-c-bg);
    padding-top:1px ;
    width: 100%;
    box-sizing: border-box;
 
    top:0;
    
    // background: rgba(255,255,255,.7);
    position: fixed;
    display: flex;
    z-index: 9999;
    text-align: center;
    transition: all 0.3s;
    .header-search-Box{
        position: relative;
        margin:0;
        display: inline-flex;
        flex: 0.6;
        align-items: center;
        justify-items: center;
         height: auto;
         background-color: var(--tp-c-bg);
    }
    @media only screen and (max-width: 959px) {
 .header-search-Box{
    display: none;
  }
}
    .header-centent{
        flex: 4;
          display: flex;
         padding-right: 30px  ;
          backdrop-filter: saturate(50%) blur(8px);
          background-color: var(--tp-c-h-bg);
          align-items: center;
    //   justify-items: center;
    //   justify-content: center;
    }
    &.IsFixed{
        top: -75px;
         align-items:center;
        .header-box_logo{
             padding-top:95px;
        }
        .header-search-Box{
            padding-top:75px;
            height: 75px;
        }
        .content{
            padding-top: 65px;
        }
        .line{
            font-size: 0;
            width: 90px!important;
        }
         #logoSvgId{
             top: 60px!important
         }
    }
    &.IsMobile{
        
    }
    
.content {
  display: inline-flex;
  justify-content: flex-end;
  align-items: center;
 
}


//  .translations::before,
//  .appearance::before,
// .social-links::before,
// .translations + .appearance::before,
// .appearance + .social-links::before {
//   margin-right: 8px;
//   margin-left: 8px;
//   width: 1px;
//   height: 24px;
// //   background-color: var(--tp-c-divider-light);
//   content: "";
// }

 .appearance::before,
.translations + .appearance::before {
  margin-right: 16px;
}

.appearance + .social-links::before {
  margin-left: 16px;
}

.social-links {
  margin-right: -8px;
}
    .header-box_logo{
        width: 320px;
        height: 55px;
        padding-top:100px;
        transition: all 0.3s;
        position: relative;
        margin: 0 auto;
        text-align: center;
        // text-align: center;
        span{
           display: inline-block;vertical-align: middle;
        }
        .tinymce_color{
          color:#344A85 ;text-shadow: 0 3px 5px #677285;
        } 
        .line{
            display: inline-block;vertical-align: middle;
            width: 30px;
            min-height: 37px;
            max-width: 90px;
            text-align: center;
        }
        #logoSvgId{
            position: absolute;
            top:0px;
            left:50%;
            margin-left: -43px;
        }
        .header_logo{
            &.animated{
                #logoSvgBottom{
                     fill-opacity: 0.75;
                }
            }
            #logoSvgBottom{
                fill-opacity: 0;
                transition: all 0.3s;
            }
        }
        .plugin_color{
          color: #43B984;text-shadow: 0 3px 5px #34435C;
        }
    }
}
   
</style>