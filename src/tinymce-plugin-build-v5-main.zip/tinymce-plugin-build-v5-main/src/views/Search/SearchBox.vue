<template>
  <div class="search-box">
   <div id="docsearch"></div>
  </div>
</template>

<script lang='ts'>
import { computed, defineComponent, ref } from '@vue/runtime-core'
// import matchQuery from './match-query'
import '@docsearch/css';
import docsearch from '@docsearch/js';

import { transformI18n ,$t} from "/@/i18n";
import { useRoute, useRouter } from '@npkg/vue-router';


function isSpecialClick(event: MouseEvent) {
  return (
    event.button === 1 ||
    event.altKey ||
    event.ctrlKey ||
    event.metaKey ||
    event.shiftKey
  )
}
function getRelativePath(absoluteUrl: string) {
  const { pathname, hash } = new URL(absoluteUrl)
  return pathname + hash
}
function debounce(func, wait = 100) {
  let lastTimeout = null;
  return function (...args) {
    const that = this;
    return new Promise((resolve, reject) => {
      if (lastTimeout) {
        clearTimeout(lastTimeout);
      }
      lastTimeout = setTimeout(() => {
        lastTimeout = null;
        Promise.resolve(func.apply(that, args)).then(resolve).catch(reject);
      }, wait);
    });
  };
}
/* global SEARCH_MAX_SUGGESTIONS, SEARCH_PATHS, SEARCH_HOTKEYS */
export default defineComponent({
  name: 'SearchBox',
  setup(){
const route = useRoute()
const router = useRouter()
return {
  route,
  router
}
  },
  mounted(){
   docsearch({
      container: '#docsearch',
      appId: 'LIXBD9IHZ6',
      apiKey: 'd6925092b4555ac6b68e70fcbf4faf7e',
      indexName: 'tinymce-plugin-dev',
      placeholder: transformI18n($t('tp.searchPlaceholder')),
      context:["five-great"],
    
      // algoliaOptions:{
      //   facetFilters: ['lang:zh', 'version:2.0.0'],
      // },
      searchParameters: {
        hitsPerPage: 10,
        // facetFilters: ["lang:zh-CN","tags:v2"],
      },
      transformSearchClient: (searchClient) => {
          return {
            ...searchClient,
            search: debounce(searchClient.search, 500)
          };
      },
      getMissingResultsUrl: (searchFor) => {
        return `https://github.com/tinymce-plugin/tinymce-plugin.github.io/discussions?discussions_q=${searchFor}`;
      },
      translations:{
        button: {
          buttonText: transformI18n($t('tp.searchButtonText')),
          buttonAriaLabel: 'Search',
        },
        modal: {
          searchBox: {
            resetButtonTitle: transformI18n($t('tp.searchClear')),
            resetButtonAriaLabel: 'Clear the query',
            cancelButtonText: transformI18n($t('tp.searchCancel')),
            cancelButtonAriaLabel: 'Cancel',
          },
        startScreen: {
          recentSearchesTitle: transformI18n($t('tp.searchRecentSearches')),
          noRecentSearchesText: transformI18n($t('tp.searchNoRecentSearches')),
          saveRecentSearchButtonTitle: transformI18n($t('tp.searchSaveRecentSearch')),
          removeRecentSearchButtonTitle: transformI18n($t('tp.searchRemoveRecentSearch')),
          favoriteSearchesTitle: transformI18n($t('tp.searchFavoriteSearches')),
          removeFavoriteSearchButtonTitle: transformI18n($t('tp.searchRemoveFavoriteSearch')),
        },
        errorScreen: {
          titleText: transformI18n($t('tp.searchErrorScreen')),
          helpText: transformI18n($t('tp.searchHelp')),
        },
          footer:{
                selectText: transformI18n($t('tp.searchSelect')),
                selectKeyAriaLabel: 'Enter key',
                navigateText:  transformI18n($t('tp.searchNavigate')),
                navigateUpKeyAriaLabel: 'Arrow up',
                navigateDownKeyAriaLabel: 'Arrow down',
                closeText: transformI18n($t('tp.searchClose')),
                closeKeyAriaLabel: 'Escape key',
                searchByText: transformI18n($t('tp.searchSearchBy')),
          },
        noResultsScreen: {
          noResultsText:  transformI18n($t('tp.searchNoResultsText')),
          suggestedQueryText:  transformI18n($t('tp.searchSuggestedQuery')),
          reportMissingResultsText: transformI18n($t('tp.searchReportMissingResults')),
          reportMissingResultsLinkText: transformI18n($t('tp.searchReportMissingResultsLink')),
         },
        },
      },
      navigator: {
        navigate: ({ itemUrl }: { itemUrl: string }) => {
          const { pathname: hitPathname } = new URL(
            window.location.origin + itemUrl
          )
          // Router doesn't handle same-page navigation so we use the native
          // browser location API for anchor navigation
          if (this.route.path === hitPathname) {
            window.location.assign(window.location.origin + itemUrl)
          } else {
            // console.log(itemUrl);
                    // window.location.assign(relativeHit);
                    this.router.push(itemUrl)
           // this.router.go(itemUrl)
          }
        }
      },
      hitComponent: ({
        hit,
        children
      }: {
        hit: any
        children: any
      }) => {
        // console.log(hit);
        // console.log(children);
        
        const relativeHit = hit.url.startsWith('http')
          ? getRelativePath(hit.url as string)
          : hit.url
        return {   
          type: 'a',
          ref: undefined,
          constructor: undefined,
          key: undefined,
          props: {
            href: hit.url,
            onClick: (event: MouseEvent) => {
              if (isSpecialClick(event)) {
                return
              }
              // we rely on the native link scrolling when user is already on
              // the right anchor because Router doesn't support duplicated
              // history entries
              // console.log(relativeHit);
              // console.log(this.route?.path);
              if (this.route?.path === relativeHit) {
                return
              }
              // if the hits goes to another page, we prevent the native link
              // behavior to leverage the Router loading feature
              if (this.route?.path !== relativeHit) {
                event.preventDefault()
              }
                //  console.log(this.router);
                this.router.push(relativeHit)
            },
            children
          },
          __v: null
        }
      }
    });
  }
})
</script>
<style>
.search-box {
    display: inline-block;
    position: relative;
    margin-left: 10px;
    z-index: 999;
    margin-right: 1rem;
    /* flex: 0.5; */
    width: 80%;
   /* flex: 0.6; */
   /* background-color: var(--tp-c-bg); */

}

@media only screen and (min-width: 1601px) and (max-width: 1900px) {
  .search-box {
    width: 100%;
}
}
@media only screen and (min-width: 960px) and (max-width: 1600px) {
  .search-box {
    width: 180px;
  }
}

element.style {
}
.DocSearch-Dropdown {
    max-height: calc(var(--docsearch-modal-height) - var(--docsearch-searchbox-height) - var(--docsearch-spacing) - var(--docsearch-footer-height));
    min-height: var(--docsearch-spacing);
    overflow-y: auto;
    overflow-y: overlay;
    padding: 0 var(--docsearch-spacing);
    scrollbar-color: var(--docsearch-muted-color) var(--docsearch-modal-background);
    scrollbar-width: thin;
}
.DocSearch-Container, .DocSearch-Container * {
    box-sizing: border-box;
}
user agent stylesheet
div {
    display: block;
}
style attribute {
    --docsearch-vh: 12.41px;
}
.DocSearch {
    --docsearch-primary-color: var(--tp-c-brand);
    --docsearch-text-color: var(--tp-c-text-1);
    --docsearch-highlight-color: #43B984;
    --docsearch-muted-color: #999999;
    --docsearch-container-background: rgba(9, 10, 17, .8);
    --docsearch-modal-background: var(--);
    --docsearch-modal-background: var(--tp-c-bg-soft);
    --docsearch-footer-background: var(--tp-c-bg)
    --docsearch-searchbox-background: #eeeeee;
    --docsearch-searchbox-focus-background: #fff;
    --docsearch-searchbox-shadow: inset 0 0 0 2px #43B984;
    --docsearch-hit-color: #3a5169;
    --docsearch-hit-active-color: #ffffff;
    --docsearch-hit-background: #ffffff;
    --docsearch-hit-shadow: 0 1px 3px 0 #dfe2e5;
}
.DocSearch-Container{
  z-index: 9999;
  font-size: initial;
}
.DocSearch-Hits .DocSearch-Hit[aria-selected=true] mark{
  color: #074180!important;
}
.DocSearch-Logo svg {
    color: #4e6e8e;
    margin-left: 8px;
}
.search-box .DocSearch-Button{
  width: calc(100% - 28px);
  font-size: initial;
}
.DocSearch-Container .DocSearch-Modal{
  font-size: initial;
}
.dark .DocSearch {
    --docsearch-modal-shadow: none;
    --docsearch-footer-shadow: none;
    --docsearch-logo-color: var(--tp-c-text-2);
    --docsearch-hit-background: var(--tp-c-bg-mute);
    --docsearch-hit-color: var(--tp-c-text-2);
    --docsearch-hit-shadow: none
}
.search-box .DocSearch-Button:hover{
      /* color:#3eaf7c */
      box-shadow: inset  0 0 0 2px #4e6e8e
  }
/* .DocSearch .DocSearch-Container{
  font-size: 16px;
} */
.search-box input {
font-size: initial;
    cursor: text;
    width: 10rem;
    height: 2rem;
    color: #4e6e8e;
    display: inline-block;
    border: 1px solid #cfd4db;
    border-radius: 2rem;
    font-size: .9rem;
    line-height: 2rem;
    padding: 0 .5rem 0 2rem;
    outline: none;
    transition: all .2s ease;
    background: #fff url('./search.svg') .6rem .5rem no-repeat;
    background-size: 1rem
}

.search-box input:focus {
    cursor: auto;
    border-color: #3eaf7c
}

.search-box .suggestions {
    background: #fff;
    width: 20rem;
    position: absolute;
    top: 2rem;
    border: 1px solid #cfd4db;
    border-radius: 6px;
    padding: .4rem;
    list-style-type: none
}

.search-box .suggestions.align-right {
    right: 0
}

.search-box .suggestion {
    line-height: 1.4;
    padding: .4rem .6rem;
    border-radius: 4px;
    cursor: pointer
}

.search-box .suggestion a {
    white-space: normal;
    color: #5d82a6
}

.search-box .suggestion a .page-title {
    font-weight: 600
}

.search-box .suggestion a .header {
    font-size: .9em;
    margin-left: .25em
}

.search-box .suggestion.focused {
    background-color: #f3f4f5
}

.search-box .suggestion.focused a {
    color: #3eaf7c
}

/* @media (max-width: 959px) {
    .search-box input {
        cursor:pointer;
        width: 0;
        border-color: transparent;
        position: relative
    }

    .search-box input:focus {
        cursor: text;
        left: 0;
        width: 10rem
    }
} */

@media (-ms-high-contrast:none) {
    .search-box input {
        height: 2rem
    }
}

@media (max-width: 959px) and (min-width:719px) {
    .search-box .suggestions {
        left:0
    }
}

@media (max-width: 719px) {
    .search-box {
        margin-right:0
    }

    .search-box input {
        left: 1rem
    }

    .search-box .suggestions {
        right: 0
    }
}

@media (max-width: 419px) {
    .search-box .suggestions {
        width:calc(100vw - 4rem)
    }

    .search-box input:focus {
        width: 8rem
    }
}
</style>
