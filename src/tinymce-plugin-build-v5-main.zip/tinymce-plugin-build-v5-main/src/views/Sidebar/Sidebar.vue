<template>
  <div
    class="sidebar-Box"
    v-if="store[store.language=='en'?'menuList_en':'menuList']?.length > 0"
    @click.stop="() => {}"
  >
    <div class="top-bage">
      <p class="Sponsor">
        <a href="https://github.com/Five-great" title="Sponsor Li Haolong"
          ><img
            src="https://avatars.githubusercontent.com/u/43601963?s=60&amp;amp;v=4"
            alt=""
        /></a>
      </p>
      <!-- <p><a href="https://github.com/tinymce-plugin" target="_blank"><img src="https://tinymce-plugin.github.io/badge.svg" alt="tinymce-plugin"></a></p> -->
    </div>

    <ul class="sidebar-ul">
      <li
        v-for="(item, index) in store[store.language=='en'?'menuList_en':'menuList']"
        :key="index"
        class="sidebar-li"
        :data-ison="seletIdx === index ? true : false"
      >
        <div v-if="item.children && item.children.length > 0">
          <router-link
            :to="item.path + '/' + item.children[0].path"
            class="sidebar-title"
            >{{ store.language=='en'?item.name.replace(/\/en$/,'') : item.meta ? item.meta.title : item.name }}</router-link
          >
          <ul class="sidebar-cUl">
            <li
              v-for="(cItem, cIndex) in item.children"
              :key="cIndex"
              class="sidebar-cLi"
              :data-ison="seletcIdx === cIndex ? true : false"
            >
              <div v-if="cItem.children && cItem.children.length > 0">
                <router-link
                  :to="
                    item.path + '/' + cItem.path + '/' + cItem.children[0].path
                  "
                  class="sidebar-cTitle"
                  ><span>{{ cItem.meta ? cItem.meta.title : cItem.name }}</span
                  ><em>{{
                    cItem.meta && cItem.meta.remark
                      ? " | " + cItem.meta.remark
                      : ""
                  }}</em>
                </router-link>
                <ul class="sidebar-ccUl">
                  <li
                    v-for="(ccItem, ccIndex) in cItem.children"
                    :key="ccIndex"
                    class="sidebar-ccLi"
                  >
                    <router-link
                      :to="item.path + '/' + cItem.path + '/' + ccItem.path"
                      class="sidebar-ccTitle"
                      >{{
                        ccItem.meta ? ccItem.meta.title : ccItem.name
                      }}</router-link
                    >
                  </li>
                </ul>
              </div>
              <router-link
                v-else
                :to="item.path + '/' + cItem.path"
                class="sidebar-cTitle"
                ><span>{{ cItem.meta ? cItem.meta.title : cItem.name }}</span
                ><em>{{
                  cItem.meta && cItem.meta.pluginName
                    ? " | " + cItem.meta.pluginName
                    : ""
                }}</em>
              </router-link>
            </li>
          </ul>
        </div>
        <router-link class="sidebar-title" v-else :to="item.path">{{
          item.meta ? item.meta.title : item.name
        }}</router-link>
      </li>
      <li class="sidebar-li outline outlink">
        <modalBox ref="outLinkQABox" title="互助问答区">
          <template #show>
            <div class="sidebar-title">
              <span>{{ transformI18n("tp.QandAarea") }}</span>
              <svg
                class="icon outbound icon"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                x="0px"
                y="0px"
                viewBox="0 0 100 100"
                width="20"
                height="20"
                data-v-1501f284=""
              >
                <path
                  fill="currentColor"
                  d="M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z"
                ></path>
                <polygon
                  fill="currentColor"
                  points="45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9"
                ></polygon>
              </svg>
            </div>
          </template>
          <div class="edit-page_box">
            <a
              href="https://github.com/tinymce-plugin/tinymce-plugin.github.io/discussions/categories/q-a"
              target="_blank"
              @click.stop="closeOpen"
            >
              <svg
                height="128"
                aria-hidden="true"
                viewBox="0 0 16 16"
                version="1.1"
                width="128"
                data-view-component="true"
                class="octicon octicon-mark-github v-align-middle"
              >
                <path
                  fill-rule="evenodd"
                  d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"
                ></path>
              </svg>
              <br />
              <br />
              <span>Github{{ transformI18n("tp.QandAarea") }}</span
              ><svg
                class="icon outbound icon"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                x="0px"
                y="0px"
                viewBox="0 0 100 100"
                width="15"
                height="15"
                data-v-1501f284=""
              >
                <path
                  fill="currentColor"
                  d="M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z"
                ></path>
                <polygon
                  fill="currentColor"
                  points="45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9"
                ></polygon></svg
            ></a>
            <a
              href="https://gitee.com/tinymce-plugin/tinymce-plugin/issues"
              target="_blank"
              @click.stop="closeOpen"
            >
              <svg
                t="1648028102473"
                class="icon"
                viewBox="0 0 1024 1024"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                p-id="2405"
                width="128"
                height="128"
              >
                <path
                  d="M512 1024C229.222 1024 0 794.778 0 512S229.222 0 512 0s512 229.222 512 512-229.222 512-512 512z m259.149-568.883h-290.74a25.293 25.293 0 0 0-25.292 25.293l-0.026 63.206c0 13.952 11.315 25.293 25.267 25.293h177.024c13.978 0 25.293 11.315 25.293 25.267v12.646a75.853 75.853 0 0 1-75.853 75.853h-240.23a25.293 25.293 0 0 1-25.267-25.293V417.203a75.853 75.853 0 0 1 75.827-75.853h353.946a25.293 25.293 0 0 0 25.267-25.292l0.077-63.207a25.293 25.293 0 0 0-25.268-25.293H417.152a189.62 189.62 0 0 0-189.62 189.645V771.15c0 13.977 11.316 25.293 25.294 25.293h372.94a170.65 170.65 0 0 0 170.65-170.65V480.384a25.293 25.293 0 0 0-25.293-25.267z"
                  fill="#C71D23"
                ></path>
              </svg>
              <br />
              <br />
              <span>Gitee{{ transformI18n("tp.QandAarea") }}</span
              ><svg
                class="icon outbound icon"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                x="0px"
                y="0px"
                viewBox="0 0 100 100"
                width="15"
                height="15"
                data-v-1501f284=""
              >
                <path
                  fill="currentColor"
                  d="M18.8,85.1h56l0,0c2.2,0,4-1.8,4-4v-32h-8v28h-48v-48h28v-8h-32l0,0c-2.2,0-4,1.8-4,4v56C14.8,83.3,16.6,85.1,18.8,85.1z"
                ></path>
                <polygon
                  fill="currentColor"
                  points="45.7,48.7 51.3,54.3 77.2,28.5 77.2,37.2 85.2,37.2 85.2,14.9 62.8,14.9 62.8,22.9 71.5,22.9"
                ></polygon></svg
            ></a>
          </div>
        </modalBox>
      </li>
      <li class="sidebar-li"><img style="width:100%;max-width: 200px; margin-top: 30px;" src="https://img-blog.csdnimg.cn/3f6bfbf7766c4619a2af584dd6e9f12c.png" alt=""/></li>
    </ul>
    <!-- <ul class="sidebar-bottom">
       <li><a href="https://github.com/tinymce-plugin"><em><img src="https://avatars.githubusercontent.com/u/87648636?s=200&v=4" width="25"></em><span>github仓库地址</span></a></li>
   </ul> -->
  </div>
</template>

<script lang="ts">
import { transformI18n } from "/@/i18n";
import { computed, defineComponent, nextTick, ref } from "vue";
import { useStore } from "/@/stores";
export default defineComponent({
  name: "Sidebar",
  data() {
    return {
      sidebarList: [],
    };
  },
  setup() {
    const store = useStore();
    const seletcIdx = ref(0);
    const outLinkQABox = ref();
    const seletIdx = computed(() => {
      let _idx = 0;
 
      store[store.language=='en'?'menuList_en':'menuList'].some((ele, idx) => {
        if (
          store.pageRoute &&
          store.pageRoute.matched &&
          ele.path === store.pageRoute.matched[0]?.path
        ) {
          //    console.log(store.pageRoute.matched)
          if (store.pageRoute.matched.length > 1) {
            //    console.log(ele.children);
            ele.children.some((cEle, cIdx) => {
              if (
                ele.path + "/" + cEle.path ===
                store.pageRoute.matched[1].path
              ) {
                seletcIdx.value = cIdx;
                return true;
              }
            });
          }
          _idx = idx;
          return true;
        }
        return false;
      });
      return _idx;
    });
    // seletIdx.value
    // const seletIdxFn =(idx:number)=>{
    //     seletIdx.value = idx
    // }
    const closeOpen = () => {
      outLinkQABox.value.clickCloseFn();
    };

    return {
      store,
      seletIdx,
      seletcIdx,
      closeOpen,
      transformI18n,
      // seletIdxFn
    };
  },
});
</script>

<style lang="scss" scoped>

  .en{
    .sidebar-Box{
      ul.sidebar-ul .sidebar-li .sidebar-title {
            font-size: 16px;
            letter-spacing: 0px;
          }
    }

  }
@media only screen and (max-width: 959px) {
  .sidebar-Box {
    li > div > a {
      // pointer-events: none;
    }
  }
}
.sidebar-Box {
  height: 100%;
  min-height: 100%;
  max-height: 100%;
  width: 100%;
  padding-top: 1px;

  .top-bage {
    min-height: 80px;
    text-align: center;
    .Sponsor {
      padding: 0;
      margin: 0;
      padding-right: 40px;
      & > a {
        margin: 0 auto;
        display: block;
        width: 60px;
        height: 60px;

        border-radius: 40px;
        overflow: hidden;
      }
      span {
        letter-spacing: 1px;
        font-size: 14px;
        color: var(--tp-c-text-1);
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif;
        display: inline-block;
        vertical-align: middle;
      }
    }
  }
  ul.sidebar-ul {
    margin: 0;
    padding-left: 15px;
    //   margin-top: 20px;
    // //   border-top: 2px solid #eee;
    //   padding-top: 20px;
    padding-right: 15px;
    padding-bottom: 30px;
    max-height: calc(100vh - 195px);
    overflow: auto;
    &::-webkit-scrollbar {
      width: 0px;
    }

    &::-webkit-scrollbar-track {
      background-color: #344a85;
    }

    &::-webkit-scrollbar-thumb {
      background-color: #344a85;
    }

    .sidebar-li {
      list-style: none;
      margin: 10px 0;
      &.outline {
        border-top: 2px solid #eee;
        padding-top: 15px;
        margin-top: 15px;
      }
      &.outlink {
        svg {
          display: inline-block;
          vertical-align: middle;
          margin-left: 15px;
        }
      }
      &[data-ison="true"] {
        & > div > a {
          color: $themeBrightColor !important;
          text-shadow: 0 1px 2px $themeBrightColor;
        }
        .sidebar-cUl {
          max-height: 100000px;
        }
      }
      .router-link-active {
        color: $themeBrightColor !important;
      }
      .router-link-exact-active {
        text-shadow: 0 1px 2px $themeBrightColor;
      }
      .sidebar-cUl {
        max-height: 0px;
        overflow: hidden;
        padding-left: 20px;
        transition: all 0.2s;
        .sidebar-cLi {
          margin: 8px 0;
          list-style: none;
          .sidebar-cTitle {
            text-decoration: none;
            color: var(--tp-c-text-1);
            em {
             font-style: normal;
              font-size: 0.5em;
            }
          }
          &[data-ison="true"] {
            & > div > a {
              color: $themeBrightColor !important;
              text-shadow: 0 1px 2px $themeBrightColor;
            }
            .sidebar-ccUl {
              max-height: 100000px;
            }
          }
          .sidebar-ccUl {
            max-height: 0px;
            overflow: hidden;
            padding-left: 20px;
            transition: all 0.2s;
            .sidebar-ccLi {
              margin: 4px 0;
              list-style: none;
              .sidebar-ccTitle {
                text-decoration: none;
                color: var(--tp-c-text-1);
                font-size: 0.9em;
                em {
                  font-size: 0.4em;
                }
              }
            }
          }
        }
      }
      .sidebar-title {
        text-decoration: none;
        font-size: 20px;
        letter-spacing: 1px;
        font-weight: bold;
        color: var(--tp-c-text-1);
      }
    }
  }
  ul.sidebar-bottom {
    padding-left: 15px;
    padding-top: 15px;
    border-top: 1px solid #eee;
    li {
      list-style: none;
      a {
        text-decoration: none;
        font-size: 20px;
        font-weight: bold;
        color: var(--tp-c-text-1);
        span,
        em {
          display: inline-block;
          vertical-align: middle;
          height: 100%;
        }
        em {
          font-size: 0;
        }
      }
    }
  }
}
</style>