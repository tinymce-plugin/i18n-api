/**
 *  api 接口
 * */
import { http } from "../../tools/http";
const GlobalApi = {
  github:{
    api: "https://api.github.com",
    org: "tinymce-plugin"
    // org: "vuejs"
  },
  gitee:{
    api: "https://api.github.com",
    org: "tinymce-plugin"
  },
  jsdelivrApi: "https://cdn.jsdelivr.net/gh/tinymce-plugin"
}
export default {   
/**
  *
  * 获取组织所有公用仓库
  * @return {*} 
  */
 async getRepos(): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/orgs/${GlobalApi.github.org}/repos?org=org&type=public&page=1&per_page=100`);
    return resData
   },
  /**
   * 获取单个仓库信息
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
  async getRepo(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}`);
    return resData
  },
  /**
   *获取单个仓库贡献者信息
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
  async getContributors(repo: any): Promise<any>{
  const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/contributors?page=1&per_page=100`);
  return resData
  },
   /**
   *获取单个仓库Tags
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getTags(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/tags`);
    return resData
    },
    /**
   *获取单个仓库主题
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getTopics(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/topics`);
    return resData
    }
    ,
    /**
   *获取单个仓库主题
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getPages(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/pages`);
    return resData
    },
    /**
   *获取提交列表
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getCommitsList(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/commits?page=1&per_page=100`);
    return resData
    },
   /**
   *获取issues
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getIssues(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/issues?page=1&per_page=100`);
    return resData
    },
     /**
   *获取views
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getViews(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/traffic/views`);
    return resData
    },
  /**
   *获取Releases
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getReleases(repo: string): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/releases`);
    return resData
    },
     /**
   *获取ReleasesLatest
   *
   * @param {*} repo 仓库名
   * @return {*} 
   */
   async getReleasesLatest(repo: any): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/releases/latest`);
    return resData
    },
   /**
   *获取ContributorsList
   *
   * @param {*} repo 仓库名
   * @param {*} path 文件路径
   * @return {*} 
   */
   async getContributorsList(repo: any,path: any): Promise<any>{
    const resData = await http.request("get", `https://github.com/${GlobalApi.github.org}/${repo}/contributors-list/main/${path}`);
    return resData
    },
    /**
   *获取contents
   *
   * @param {*} repo 仓库名
   * @param {*} path 路径
   * @return {*} 
   */
   async getContents(repo: string,path=''): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/contents/${path}`);
    return resData
    },
     /**
   *获取Releases
   *
   * @param {*} repo 仓库名
   * @param {*} path 路径
   * @return {*} 
   */
   async getTrees(repo: string,path=''): Promise<any>{
    const resData = await http.request("get", `${GlobalApi.github.api}/repos/${GlobalApi.github.org}/${repo}/git/trees/${path}`);
    return resData
    }
}