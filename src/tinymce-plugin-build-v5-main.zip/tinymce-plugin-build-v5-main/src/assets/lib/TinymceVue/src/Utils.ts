/**
 * Copyright (c) 2018-present, Ephox, Inc.
 *
 * This source code is licensed under the Apache 2 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */
import tinymce, { EditorEvent, Editor as TinyMCEEditor } from 'tinymce';
import { Ref, ref, SetupContext, watch } from 'vue';
import { IPropTypes } from './EditorPropTypes';
var validEvents = [
    'onActivate',
    'onAddUndo',
    'onBeforeAddUndo',
    'onBeforeExecCommand',
    'onBeforeGetContent',
    'onBeforeRenderUI',
    'onBeforeSetContent',
    'onBeforePaste',
    'onBlur',
    'onChange',
    'onClearUndos',
    'onClick',
    'onContextMenu',
    'onCopy',
    'onCut',
    'onDblclick',
    'onDeactivate',
    'onDirty',
    'onDrag',
    'onDragDrop',
    'onDragEnd',
    'onDragGesture',
    'onDragOver',
    'onDrop',
    'onExecCommand',
    'onFocus',
    'onFocusIn',
    'onFocusOut',
    'onGetContent',
    'onHide',
    'onInit',
    'onKeyDown',
    'onKeyPress',
    'onKeyUp',
    'onLoadContent',
    'onMouseDown',
    'onMouseEnter',
    'onMouseLeave',
    'onMouseMove',
    'onMouseOut',
    'onMouseOver',
    'onMouseUp',
    'onNodeChange',
    'onObjectResizeStart',
    'onObjectResized',
    'onObjectSelected',
    'onPaste',
    'onPostProcess',
    'onPostRender',
    'onPreProcess',
    'onProgressState',
    'onRedo',
    'onRemove',
    'onReset',
    'onSaveContent',
    'onSelectionChange',
    'onSetAttrib',
    'onSetContent',
    'onShow',
    'onSubmit',
    'onUndo',
    'onVisualAid'
];
var isValidKey = function (key: string): string | boolean {
    return validEvents.map(function (event) { return event.toLowerCase(); }).indexOf(key.toLowerCase()) !== -1;
};
var bindHandlers = function (initEvent: EditorEvent<any>, listeners: any, editor: TinyMCEEditor) {
    Object.keys(listeners)
        .filter(isValidKey)
        .forEach(function (key) {
            var handler = listeners[key];
            if (typeof handler === 'function') {
                if (key === 'onInit') {
                    handler(initEvent, editor);
                }
                else {
                    editor.on(key.substring(2), function (e) { return handler(e, editor); });
                }
            }
        });
};
var bindModelHandlers = function (props, ctx, editor, modelValue) {
    var modelEvents = props.modelEvents ? props.modelEvents : null;
    var normalizedEvents = Array.isArray(modelEvents) ? modelEvents.join(' ') : modelEvents;
    // watch(modelValue, function (val, prevVal) {
    //     //  console.log(prevVal);
    //     //  console.log(val);
         
    //     if (editor && typeof val === 'string' && val !== prevVal&&(val !== editor.getContent({ format: props.outputFormat })||(typeof editor.setTpContent ==='function'&&val !== editor.getContent({ format: props.outputFormat })))) {
    //       typeof editor.setTpContent ==='function'? editor.setTpContent(val):editor.setContent(val);
    //        editor.setContent(val);
    //     }
    // });
    editor.on(normalizedEvents ? normalizedEvents : 'input  focus focusin click focusout drop ObjectResized keydown paste ExecCommand ObjectSelected', function () {
        // input  focus focusin click focusout drop ObjectResized keydown paste ExecCommand ObjectSelected
        // console.log( editor.getTpStyle());
        ctx.emit('update:modelValue', typeof editor.getTpContent ==='function' ? editor.getTpContent({ format: props.outputFormat }) : editor.getContent({ format: props.outputFormat }));
        // ctx.emit('update:modelValue',  editor.getContent({ format: props.outputFormat }));
    });
   //@ts-ignore
   tinymce.tinymcePlugin&&setIntervalFn((clear)=>{
        if(typeof editor.getTpContent ==='function'){
            clear()
            // modelValue.value = editor.getTpContent({ format: props.outputFormat });
            // console.log( editor.getTpContent({ format: props.outputFormat }));
            ctx.emit('update:modelValue', editor.getTpContent({ format: props.outputFormat })) 
            ctx.emit('update:modelValue', editor.getTpContent({ format: props.outputFormat })) 
        }
    },50);
    // setInterval(() => {
    // ctx.emit('update:modelValue', typeof editor.getTpContent ==='function' ? editor.getTpContent({ format: props.outputFormat }) : editor.getContent({ format: props.outputFormat }));
    // })
};
var initEditor = function (initEvent: EditorEvent<any>, props: IPropTypes, ctx: SetupContext, editor: TinyMCEEditor, modelValue: Ref<any>, content: () => string) {
   //@ts-ignore
    typeof editor.setTpContent === 'function'?editor.setTpContent(content()):editor.setContent(content());
    if (ctx.attrs['onUpdate:modelValue']) {
        bindModelHandlers(props, ctx, editor, modelValue);
    }
    bindHandlers(initEvent, ctx.attrs, editor);
};
var unique = 0;
var uuid = function (prefix: string): string {
    var time = Date.now();
    var random = Math.floor(Math.random() * 1000000000);
    unique++;
    return prefix + '_' + random + unique + String(time);
};
var isTextarea = function (element: Element | null): HTMLTextAreaElement | boolean {
    return element !== null && element.tagName.toLowerCase() === 'textarea';
};
var normalizePluginArray = function (plugins) {
    if (typeof plugins === 'undefined' || plugins === '') {
        return [];
    }
    return Array.isArray(plugins) ? plugins : plugins.split(' ');
};

var mergePlugins = function (initPlugins: string | string[], inputPlugins?: string | string[] | undefined): string[] {
    return normalizePluginArray(initPlugins).concat(normalizePluginArray(inputPlugins));
};
var isNullOrUndefined = function (value: any): null | undefined | boolean {
    return value === null || value === undefined;
};

/**
 *  定时器 超时自动关闭 
 * @param func 
 * @param delay 
 * @param outTime 
 */
 export const setIntervalFn = (func:any, delay:number,outTime?:number)=>{
    !outTime&&(outTime = delay*1000)
    let setIntervalObj:any = {
      id: null,
      outTime: outTime,
      outId: null,
    }
    setIntervalObj.id = setInterval((obj)=>{
      func(()=>{
        clearTimeout(obj.outId)
        clearInterval(obj.id)
      })
    },delay,setIntervalObj)
    setIntervalObj.outId = setTimeout(()=>{
      setIntervalObj.id&&clearInterval(setIntervalObj.id)
    },setIntervalObj.outTime)
   
  }
export { bindHandlers, bindModelHandlers, initEditor, isValidKey, uuid, isTextarea, mergePlugins, isNullOrUndefined };
