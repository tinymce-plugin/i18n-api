
import { RawEditorSettings, TinyMCE } from 'tinymce';
export interface EditorOptions extends RawEditorSettings {
    skeletonScreen?: boolean;
}
export declare type CopyProps<T> = {
    [P in keyof T]: any;
};
export interface IPropTypes {
    apiKey: string;
    cloudChannel: string;
    id: string;
    init: EditorOptions;
    initialValue: string;
    outputFormat: 'html' | 'text';
    inline: boolean;
    modelEvents: string[] | string;
    plugins: string[] | string;
    tagName: string;
    toolbar: string[] | string;
    modelValue: string;
    disabled: boolean;
    tinymceScriptSrc: string;
}
// export declare const editorProps: ;


export const editorProps: CopyProps<IPropTypes> = {
    apiKey: String,
    cloudChannel: String,
    id: String,
    init: Object as EditorOptions,
    initialValue: String,
    inline: Boolean,
    modelEvents: [String, Array],
    plugins: [String, Array],
    tagName: String,
    toolbar: [String, Array],
    modelValue: String,
    disabled: Boolean,
    tinymceScriptSrc: String,
    outputFormat: {
        type: String,
        validator: function (prop) { return prop === 'html' || prop === 'text'; }
    },
};
