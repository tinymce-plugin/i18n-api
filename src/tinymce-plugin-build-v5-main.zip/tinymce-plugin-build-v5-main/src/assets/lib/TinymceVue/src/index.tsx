import { ref, nextTick, defineComponent, h, onActivated, onBeforeUnmount, onDeactivated, toRefs, watch,onMounted, computed } from "vue";
import { initEditor, isNullOrUndefined, isTextarea, mergePlugins, setIntervalFn, uuid } from "./Utils";
import { editorProps, IPropTypes, EditorOptions } from "./EditorPropTypes";
// import tinymce, { TinyMCE } from "tinymce";
// import "@npkg/tinymce-plugin"
import { ScriptLoader } from "./ScriptLoader";


const defaultOptions: EditorOptions = {
  min_height: 300,
  // menubar: false,
  plugins: ['code hr'],
  toolbar: ['code hr'],
  schema: 'html5',
  // skin: false,
  // content_css: false,
  table_default_attributes: {
    'border': '1'
  },
  table_default_styles: {
    'border-collapse': 'collapse',
    'width': '100%'
  },
  table_header_type: 'sectionCells',
  table_responsive_width: true,
  file_picker_types: 'file img media',
  // object_resizing: 'table',
  fontsize_formats: '12px 14px 16px 18px 24px 36px 48px 56px 72px',
};

//@ts-ignore
var __assign: any = (this && this.__assign) || function () {
  __assign = Object.assign || function (t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var renderInline = function (ce, id, elementRef, tagName) {
  return ce('div', {}, ce(tagName ? tagName : 'div', {
    id: id,
    ref: elementRef
  }));
};
var renderIframe = function (ce, id, elementRef) {
  return ce('div', {}, ce('textarea', {
    id: id,
    visibility: 'hidden',
    ref: elementRef
  }));
};
const getGlobal = function () { return (typeof window !== 'undefined' ? window : global); };
const getTinymce = function (): any {
  var global: any = getGlobal();
 
  return global && global.tinymce ? global.tinymce : null;
};
export default defineComponent({
  name: "TinymceEditor",
  props: editorProps,
  setup: function (props: IPropTypes, ctx) {
    var conf = props.init ? __assign(defaultOptions, props.init) : {};
    var _a = toRefs(props), disabled = _a.disabled, modelValue = _a.modelValue, tagName = _a.tagName;
    var element = ref(null);
    var vueEditor = null;
    var elementId = props.id || uuid('tiny-vue');
    var inlineEditor = (props.init && props.init.inline) || props.inline;
    var modelBind = !!ctx.attrs['onUpdate:modelValue'];
    var mounting = true;
    var initialValue = props.initialValue ? props.initialValue : '';
    var cache = '';
    // var value = ref<string>(initialValue); 
    // computed(function () {
    //   if (modelBind) {
    //     return modelValue;
    //   }
    //   // return element.value;
    // });

    var getContent = function (isMounting) {
      return modelBind ?
        function () { return ((modelValue === null || modelValue === void 0 ? void 0 : modelValue.value) ? modelValue.value : ''); } :
        function () { return isMounting ? initialValue : cache; };
    };
    var initWrapper = function () {
      var content = getContent(mounting);
      var finalInit = __assign(__assign({}, conf), {
        readonly: props.disabled, selector: "#" + elementId, plugins: mergePlugins(conf.plugins, props.plugins), toolbar: props.toolbar || (conf.toolbar), inline: inlineEditor, setup: function (editor) {
          vueEditor = editor;
          // console.log(vueEditor);
          editor.on('init', function (e) {   return initEditor(e, props, ctx, editor, modelValue, content); });
          editor.on('setContent', function(e){ 
            // setIntervalFn((clear)=>{
            //   if(typeof editor.getTpContent ==='function'){
            //       clear()
            //       ctx.emit('update:modelValue', editor.getTpContent({ format: props.outputFormat })) 
            //    }
            //   },50);
            })
        //     // let _Interval = setInterval(()=>{
        //     // if(typeof editor.getTpContent === "function"){
        //     //     clearInterval(_Interval)
        //     //       ctx.emit = editor.getTpContent()
        //     //     }
        //     // },20)
     
        
           
        // })
          if (typeof conf.setup === 'function') {
            conf.setup(editor);
          }
        }
      });
      if (isTextarea(element.value)) {
        element.value.style.visibility = '';
      }
      getTinymce().init(finalInit);
      mounting = false;
    };
    watch(disabled, function (disable) {
      var _a;
      if (vueEditor !== null) {
        if (typeof ((_a = vueEditor.mode) === null || _a === void 0 ? void 0 : _a.set) === 'function') {
          vueEditor.mode.set(disable ? 'readonly' : 'design');
        }
        else {
          vueEditor.setMode(disable ? 'readonly' : 'design');
        }
      }
    });
    watch(tagName, function (_) {
      var _a;
      if (!modelBind) {
        cache = typeof vueEditor.getTpContent ==='function'? vueEditor.getTpContent() : vueEditor.getContent();
      }
      (_a = getTinymce()) === null || _a === void 0 ? void 0 : _a.remove(vueEditor);
      nextTick(function () { return initWrapper(); });
    });
    onMounted(function () {
      if (getTinymce() !== null) {
        initWrapper();
      }
      else if (element.value && element.value.ownerDocument) {
        var channel = props.cloudChannel ? props.cloudChannel : '5';
        var apiKey = props.apiKey ? props.apiKey : 'no-api-key';
        var scriptSrc = isNullOrUndefined(props.tinymceScriptSrc) ?
          "https://cdn.tiny.cloud/1/" + apiKey + "/tinymce/" + channel + "/tinymce.min.js" :
          props.tinymceScriptSrc;
        ScriptLoader.load(element.value.ownerDocument, scriptSrc, initWrapper);
      }
    });
    onBeforeUnmount(function () {
      if (getTinymce() !== null) {
        getTinymce().remove(vueEditor);
      }
    });
    if (!inlineEditor) {
      onActivated(function () {
        if (!mounting) {
          initWrapper();
        }
      });
      onDeactivated(function () {
        var _a;
        if (!modelBind) {
          cache = typeof vueEditor.getTpContent ==='function'? vueEditor.getTpContent() : vueEditor.getContent();
        }
        (_a = getTinymce()) === null || _a === void 0 ? void 0 : _a.remove(vueEditor);
      });
    }
    var rerender = function (init: IPropTypes) {
      var _a;
      cache = typeof vueEditor.getTpContent ==='function'? vueEditor.getTpContent() : vueEditor.getContent();
      (_a = getTinymce()) === null || _a === void 0 ? void 0 : _a.remove(vueEditor);
      conf = __assign(__assign({}, conf), init);
      nextTick(function () { return initWrapper(); });
    };
    ctx.expose({
      rerender: rerender
    });
    return function () {
      return inlineEditor ?
        renderInline(h, elementId, element, props.tagName) :
        renderIframe(h, elementId, element);
    };
  }
});