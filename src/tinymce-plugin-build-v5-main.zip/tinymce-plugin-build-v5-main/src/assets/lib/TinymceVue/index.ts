import { App } from "vue";
import tinymceVue from "./src";

export const TinymceEditor = Object.assign(tinymceVue, {
  install(app: App) {
    app.component(tinymceVue.name, tinymceVue);
  }
});

export default TinymceEditor;