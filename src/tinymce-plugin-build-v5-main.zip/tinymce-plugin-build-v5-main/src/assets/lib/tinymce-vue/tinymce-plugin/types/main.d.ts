import { tinymcePlugin } from './core/TinymcePlugin';
export { tinymcePlugin };
export default tinymcePlugin;
