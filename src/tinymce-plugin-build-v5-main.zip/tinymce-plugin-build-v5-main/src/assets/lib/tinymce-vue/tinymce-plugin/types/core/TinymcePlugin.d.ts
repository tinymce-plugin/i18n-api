import './global';
import "./init";
import { ComponentsApi } from "./components";
interface TinymcePlugin {
    componentsApi: ComponentsApi;
    global$1: any;
    global$7: any;
}
declare const tinymcePlugin: TinymcePlugin;
export { TinymcePlugin, tinymcePlugin };
