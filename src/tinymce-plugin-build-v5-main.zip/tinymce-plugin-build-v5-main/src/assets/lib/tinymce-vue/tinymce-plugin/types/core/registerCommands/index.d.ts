export declare const toUpdateIndent2em: (editor: any, value?: any, blocks?: any) => void;
export declare const tp$RegisterCommand: (editor: any) => void;
