export declare const createComponentsCustomTag: (editor: any) => void;
