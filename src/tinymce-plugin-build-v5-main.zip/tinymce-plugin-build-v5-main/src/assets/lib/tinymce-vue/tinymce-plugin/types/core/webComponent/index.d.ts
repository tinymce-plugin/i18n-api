export declare const setupWebComponent: (win: any, doc: Document, editor: any, _customTag: any, _tagName: string) => void;
