export declare const tp$RegisterFormatter: (editor: any) => void;
