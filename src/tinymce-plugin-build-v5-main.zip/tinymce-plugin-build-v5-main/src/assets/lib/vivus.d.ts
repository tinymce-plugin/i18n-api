declare  module 'Vivus'{
    export function Vivus(element:Element, options:Object, callback: Function ):any
}
