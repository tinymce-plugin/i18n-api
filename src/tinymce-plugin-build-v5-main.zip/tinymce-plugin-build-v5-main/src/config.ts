export const useData =()=>{
  return {
    theme:{
      footer:{
        message: 'sdsd',
        copyright: 'copyright'
      },
      value:{
        sidebar:{

        }
     },
     localeLinks: {
      items:[{
         link: 'zh',
         text: '简体中文'
  
      },{
         link: 'en',
         text: 'EngLish'
  
      }] 
    },
    socialLinks:[{
      link: "https://github.com/tinymce-plugin",
      icon: "github"
    }]
    },
    site:{
      appearance: {

      }
    },
    page: {
      value:{
        relativePath: ''
      }
    },
    frontmatter:{
      value: {
        sidebar: true
      }
    } 
  }
}
import { ref } from 'vue'
import {useRoute as _useRoute} from "@npkg/vue-router"
export const useRoute = _useRoute
export const HASH_RE = /#.*$/
export const EXT_RE = /(index)?\.(md|html)$/
export const OUTBOUND_RE = /^[a-z]+:/i

export const inBrowser = typeof window !== 'undefined'
const hashRef = ref(inBrowser ? location.hash : '')

export function isExternal(path: string): boolean {
  return OUTBOUND_RE.test(path)
}

export function throttleAndDebounce(fn: () => void, delay: number): () => void {
  let timeout: number
  let called = false

  return () => {
    if (timeout) {
      clearTimeout(timeout)
    }

    if (!called) {
      fn()
      called = true
      setTimeout(() => {
        called = false
      }, delay)
    } else {
      timeout = setTimeout(fn, delay)
    }
  }
}
export function withBase(name) {
    return name
}
export function isActive(
  currentPath: string,
  matchPath?: string,
  asRegex: boolean = false
): boolean {
  if (matchPath === undefined) {
    return false
  }

  currentPath = normalize(`/${currentPath}`)

  if (asRegex) {
    return new RegExp(matchPath).test(currentPath)
  }

  if (normalize(matchPath) !== currentPath) {
    return false
  }

  const hashMatch = matchPath.match(HASH_RE)

  if (hashMatch) {
    return hashRef.value === hashMatch[0]
  }

  return true
}