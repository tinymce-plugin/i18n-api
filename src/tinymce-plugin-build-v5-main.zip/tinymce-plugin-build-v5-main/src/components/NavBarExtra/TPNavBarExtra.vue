<script lang="ts" setup>
import { useData } from '/@/config'
import TPFlyout from '../Flyout/TPFlyout.vue'
import TPMenuLink from '../Menu/TPMenuLink.vue'
import TPSwitchAppearance from '../Appearance/TPSwitchAppearance.vue'
import TPSocialLinks from '../SocialLinks/TPNavBarSocialLinks.vue'
const { locale } = useI18n();
import { getCurrentInstance } from 'vue'
import { useI18n } from 'vue-i18n'
import { useStore } from '/@/stores'
const instance =
  getCurrentInstance().appContext.config.globalProperties.$storage;
  const store = useStore();
  function translationChange(lang) {
    instance.locale = { locale: lang };
    locale.value = lang;
}
 instance.locale = { locale: store.language };
 locale.value =store.language ;
const { site, theme } = useData()
</script>

<template>
  <TPFlyout class="TPNavBarExtra" label="extra navigation">
    <div v-if="theme.localeLinks" class="group">
      <p class="trans-title">{{ theme.localeLinks.text }}</p>

      <template v-for="locale in theme.localeLinks.items" :key="locale.link">
        <TPMenuLink :item="locale" :isLang="true"  :class="locale.link==store.language? 'active-lang':''" @click="translationChange(locale.link)" />
      </template>
    </div>

    <div v-if="site.appearance" class="group">
      <div class="item appearance">
        <p class="label">Appearance</p>
        <div class="appearance-action">
          <TPSwitchAppearance />
        </div>
      </div>
    </div>

    <div v-if="theme.socialLinks" class="group">
      <div class="item social-links">
        <TPSocialLinks class="social-links-list" :links="theme.socialLinks" />
      </div>
    </div>
  </TPFlyout>
</template>

<style scoped>
.TPNavBarExtra {
  display: none;
  margin-right: -12px;
}

@media (min-width: 768px) {
  .TPNavBarExtra {
    display: block;
  }
}

@media (min-width: 1280px) {
  .TPNavBarExtra {
    display: none;
  }
}

.trans-title {
  padding: 0 24px 0 12px;
  line-height: 32px;
  font-size: 14px;
  font-weight: 700;
  color: var(--tp-c-text-1);
}

.item.appearance,
.item.social-links {
  display: flex;
  align-items: center;
  padding: 0 12px;
}
.TPNavBarExtra .item.social-links :deep(.TPNavBarSocialLinks){
    display: flex;
    align-items: center;
}
.item.appearance {
  min-width: 176px;
}

.appearance-action {
  margin-right: -2px;
}

.social-links-list {
  margin: -4px -8px;
}
</style>
