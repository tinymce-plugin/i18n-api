<script lang="ts" setup>
import TPSocialLinks from './TPSocialLinks.vue'
import { useData } from '/@/config'
const { theme } = useData()
</script>

<template>
  <TPSocialLinks
    v-if="theme.socialLinks"
    class="TPNavBarSocialLinks"
    :links="theme.socialLinks"
  />
</template>

<style scoped>
.TPNavBarSocialLinks {
  display: none;
}


@media (min-width: 1280px) {
  .TPNavBarSocialLinks {
    display: flex;
    align-items: center;
  }
}
</style>
