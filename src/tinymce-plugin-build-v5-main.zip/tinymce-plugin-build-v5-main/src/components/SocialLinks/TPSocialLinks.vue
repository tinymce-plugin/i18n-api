<script lang="ts" setup>
import TPSocialLink from './TPSocialLink.vue'

defineProps<{
  links: String[]
}>()

</script>

<template>
  <div class="TPSocialLinks">
    <TPSocialLink
      v-for="{ link, icon } in links"
      :key="link"
      :icon="icon"
      :link="link"
    />
  </div>
</template>

<style scoped>
.TPSocialLinks {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>
