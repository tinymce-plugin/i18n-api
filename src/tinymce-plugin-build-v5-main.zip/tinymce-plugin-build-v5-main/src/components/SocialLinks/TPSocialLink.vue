<script lang="ts" setup>
import TPIconGitHub from '../icons/TPIconGitHub.vue'
import TPIconLinkedIn from '../icons/TPIconLinkedIn.vue'


defineProps<{
  icon: String
  link: string
}>()
// console.log(link);

const icons = {
  // discord: VPIconDiscord,
  github: TPIconGitHub,
 
}
</script>

<template>
  <a
    class="TPSocialLink"
    :href="link"
    :title="icon"
    target="_blank"
    rel="noopener noreferrer"
  >
    <component :is="icons[icon]" class="icon" />
    <span class="visually-hidden">{{ icon }}</span>
  </a>
</template>

<style scoped>
.TPSocialLink {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 36px;
  height: 36px;
  color: var(--tp-c-text-2);
  transition: color .5s;
}

.TPSocialLink:hover {
  color: var(--tp-c-text-1);
  transition: color .25s;
}

.icon {
  width: 20px;
  height: 20px;
  fill: currentColor;
}
</style>
