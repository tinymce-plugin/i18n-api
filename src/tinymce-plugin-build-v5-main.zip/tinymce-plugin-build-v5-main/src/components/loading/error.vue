<template>
  <div class="lazyload-wrapper">
    <div style="display: flex" class="css-vem7w7 e10ne1lt2">
     errr
      <div class="css-0 e10ne1lt0"></div>
    </div>
  </div>
</template>

<style>
.css-12vgdv0 {
    padding: 2rem 0 1rem;
    text-align: center;
    background-color: #ffffff;
    padding: 0;
    box-shadow: 0 1rem 1rem -0.625rem rgb(34 47 62 / 15%), 0 0 2.5rem 1px rgb(34 47 62 / 15%);
    border-radius: 10px;
}
@media only screen and (min-width: 768px){
.css-12vgdv0 {
    padding: 4rem 0 0;
    --gap: 0.5rem;
}
}
</style>