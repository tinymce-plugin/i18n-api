<script lang="ts" setup>
import { useData } from '/@/config'
import TPIconLanguages from '../icons/TPIconLanguages.vue'
import TPFlyout from '../Flyout/TPFlyout.vue'
import TPMenuLink from '../Menu/TPMenuLink.vue'
import { useI18n } from "vue-i18n";
const { theme } = useData()
const { locale } = useI18n();
import { useStore } from "/@/stores";
import { getCurrentInstance } from 'vue'
  const store = useStore();
const instance =
  getCurrentInstance().appContext.config.globalProperties.$storage;

  function translationChange(lang) {
    instance.locale = { locale: lang };
    locale.value = lang;
    store.chanageLanguage(lang)
   
}
 instance.locale = { locale: store.language };
 locale.value =store.language ;
</script>

<template>
  <TPFlyout
    v-if="theme.localeLinks"
    class="TPNavBarTranslations"
    :icon="TPIconLanguages"
  >
    <div class="items">
      <p class="title">{{ theme.localeLinks.text }}</p>
      <template v-for="locale in theme.localeLinks.items" :key="locale.link">
        <TPMenuLink :item="locale" :isLang="true" :class=" locale.link==store.language? 'active-lang':''" @click="translationChange(locale.link)" />
      </template>
    </div>
  </TPFlyout>
</template>

<style scoped>
.TPNavBarTranslations {
  display: none;
}

@media (min-width: 1280px) {
  .TPNavBarTranslations {
    display: flex;
    align-items: center;
  }
}

.title {
  padding: 0 24px 0 12px;
  line-height: 32px;
  font-size: 14px;
  font-weight: 700;
  color: var(--tp-c-text-1);
}

</style>
