// import SiteMap from "../siteMap"

import { http } from "../../../tools/http";
import loadingVue from "/@/components/loading/loading.vue";
import errorVue from "/@/components/loading/error.vue";
const modulesList =  import.meta.glob("../../../build/site/docs/**/*.md")
// const modulesList =  import.meta.glob("../../markdown/test/**/*.md")

// console.log(modulesList);
// console.dir(import.meta);

// @ts-ignore
import { getModulesList } from "tinymce-plugin-routes";
const setRoutes = (router)=>{
   http.request("get", `/siteMap.json`).then((resData:any)=>{
//   console.log(resData.routes);
//   resData.routes.map((ele)=>{ 
//       router.hasRoute(ele.name)&&router.removeRoute(ele.name)
//       if(ele.children&&ele.children.length>0){
//          router.addRoute({ ...ele, component:  {template: '<div class="'+ele.name+'" ><router-view></router-view></div>'}})
//          ele.children.map((e)=>{
//            if(e.children&&e.children.length>0){
//             router.addRoute(ele.name,{ ...e, component: {template: '<div class="'+e.name+'" ><router-view></router-view></div>'}})
//             e.children.map((e2)=>{
//                // console.log(import.meta.glob('../../'+e2.component+'.md'));
//               router.addRoute(e.name,{ ...e2, component: modulesList['../../'+e2.component+'.md']})
//             })
//            }else{
//             router.addRoute(ele.name,{ ...e, component: modulesList['../../'+e.component+'.md']})
//            }
            
//          })
//       }else{
//          router.addRoute({ ...ele, component: modulesList['../../'+ele.component+'.md']})
//       }
//      })
   //   router.push(router.currentRoute.value.fullPath)
// console.log( router.getRoutes());
getModulesList(router,resData,modulesList,loadingVue,errorVue)
router.push(router.currentRoute.value.fullPath).catch(()=>{});
 
      // const routes = resData.siteMap.map((item)=>{
      //    return {
      //       path: item.path,
      //       name: item.name,
      //       component: () => import(`../../${item.path}`),
      //       meta: {
      //          title: item.title,
      //       },
      //       children: item.children.map((child)=>{
      //          return {
      //             path: child.path,
      //             name: child.name,
      //             component: () => import(`../../${child.path}`),
      //             meta: {
      //                title: child.title,
      //             },
      //          }

   })
   // router
   // return SiteMap
}
export default setRoutes