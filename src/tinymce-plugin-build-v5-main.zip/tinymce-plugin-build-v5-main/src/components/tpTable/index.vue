<template>
  <div>
     <slot></slot>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue-demi";

export default defineComponent({
  name: "tpTabel",
  props:{
  },
  setup(props, ctx) {
    return {
      props,
      ctx
    }
  }
 
})


</script>
<style lang="scss" scoped>
  .modal-box {
    position: fixed;
    top: 0; right: 0; bottom: 0; left: 0;
    background-color: rgba(0,0,0,.5);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    .modal-box-body{
      position: relative;
      // display: block;
      // width: 100%;

    }
    .close-button{
      cursor: pointer;
      position: absolute;
      right: 0px;
      top: 0px;
    
      // margin-top: 300px;
      // // margin-top:50px;
      // padding: 10px 30px;
      // background: #344A85;
      // border-radius: 50px;
      // letter-spacing: 2px;
      // color: #fff;
    }
  }
  .modal-button{
    text-decoration: none;
    color: #344A85;
    cursor: pointer;
  }
  .modal-box div {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: white;
    border-radius: 4px;
  
    min-height: 300px;
    height: 20%;
    min-width: 200px;
    max-width: 500px;
    width: 80%;
    padding: 5px;
    padding-bottom: 0;
  }
</style>
