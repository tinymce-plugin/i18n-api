<script lang="ts" setup>
import TPSwitchAppearance from './TPSwitchAppearance.vue'

</script>
<template>
  <div class="TPNavBarAppearance">
    <TPSwitchAppearance />
  </div>
</template>

<style scoped>
.TPNavBarAppearance {
  display: none;
}

@media (min-width: 1280px) {
  .TPNavBarAppearance {
    display: flex;
    align-items: center;
  }
}
</style>
