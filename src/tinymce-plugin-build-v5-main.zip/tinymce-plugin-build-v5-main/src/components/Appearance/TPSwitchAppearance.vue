<script lang="ts" setup>
import TPSwitch from '../Switch/TPSwitch.vue'
import TPIconSun from '../icons/TPIconSun.vue'
import TPIconMoon from '../icons/TPIconMoon.vue'
const APPEARANCE_KEY = "APPEARANCE_KEY"
const toggle = typeof localStorage !== 'undefined' ? useAppearance() : () => {}

function useAppearance() {
  const query = window.matchMedia('(prefers-color-scheme: dark)')
  const classList = document.documentElement.classList

  let userPreference = localStorage.getItem(APPEARANCE_KEY) || 'auto'
  let isDark = userPreference === 'auto'
    ? query.matches
    : userPreference === 'dark'

  query.onchange = (e) => {
    if (userPreference === 'auto') {
      setClass((isDark = e.matches))
    }
  }
  document.querySelector('meta[name="color-scheme"]')?.setAttribute('content',userPreference)
 setClass(isDark)
  function toggle() {
    setClass((isDark = !isDark))

    userPreference = isDark
      ? query.matches ? 'auto' : 'dark'
      : query.matches ? 'light' : 'auto'
    document.querySelector('meta[name="color-scheme"]')?.setAttribute('content',userPreference)
    localStorage.setItem(APPEARANCE_KEY, userPreference)
  }

  function setClass(dark: boolean): void {
    classList[dark ? 'add' : 'remove']('dark')
  }

  return toggle
}
</script>

<template>
  <TPSwitch
    class="TPSwitchAppearance"
    aria-label="toggle dark mode"
    @click="toggle"
  >
    <TPIconSun class="sun" />
    <TPIconMoon class="moon" />
  </TPSwitch>
</template>

<style scoped>
.sun {
  opacity: 1;
}

.moon {
  opacity: 0;
}

.dark .sun {
  opacity: 0;
}

.dark .moon {
  opacity: 1;
}

.dark .TPSwitchAppearance :deep(.check) {
  transform: translateX(18px);
}
</style>
