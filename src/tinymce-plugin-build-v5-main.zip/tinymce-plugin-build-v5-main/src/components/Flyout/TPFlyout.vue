<script lang="ts" setup>
import { ref } from 'vue'
import { useFlyout } from '../../composables/flyout'
import TPIconChevronDown from '../icons/TPIconChevronDown.vue'
import TPIconMoreHorizontal from '../icons/TPIconMoreHorizontal.vue'
import TPMenu from '../Menu/TPMenu.vue'

defineProps<{
  icon?: any
  button?: string
  label?: string
  items?: any[]
}>()

const open = ref(false)
const el = ref<HTMLElement>()

useFlyout({ el, onBlur })

function onBlur() {
  open.value = false
}
</script>

<template>
  <div
    class="TPFlyout"
    ref="el"
    @mouseenter="open = true"
    @mouseleave="open = false"
  >
    <button
      type="button"
      class="button"
      aria-haspopup="true"
      :aria-expanded="open"
      :aria-label="label"
      @click="open = !open"
    >
      <span v-if="button || icon" class="text">
        <component v-if="icon" :is="icon" class="option-icon" />
        {{ button }}
        <TPIconChevronDown class="text-icon" />
      </span>

      <TPIconMoreHorizontal v-else class="icon" />
    </button>

    <div class="menu">
      <TPMenu :items="items">
        <slot />
      </TPMenu>
    </div>
  </div>
</template>

<style scoped>
.TPFlyout {
  position: relative;
}

.TPFlyout:hover {
  color: var(--tp-c-bland);
  transition: color 0.25s;
}

.TPFlyout:hover .text {
  color: var(--tp-c-text-2);
}

.TPFlyout:hover .icon {
  fill: var(--tp-c-text-2);
}

.TPFlyout:hover .menu,
.button[aria-expanded="true"] + .menu {
  opacity: 1;
  visibility: visible;
  transform: translateY(0);
}

.button {
  display: flex;
  align-items: center;
  padding: 0 12px;
  height: var(--tp-nav-height-mobile);
  color: var(--tp-c-text-1);
      background-color: transparent;
    outline: none;
    border: none;
  transition: color 0.5s;
}

@media (min-width: 960px) {
  .button {
    height: var(--tp-nav-height-desktop);
  }
}

.text {
  display: flex;
  align-items: center;
  line-height: var(--tp-nav-height-mobile);
  font-size: 14px;
  font-weight: 500;
  color: var(--tp-c-text-1);
  transition: color 0.25s;
}

@media (min-width: 960px) {
  .text {
    line-height: var(--tp-nav-height-desktop);
  }
}

.option-icon {
  margin-right: 0px;
  width: 16px;
  height: 16px;
  fill: currentColor;
}

.text-icon {
  margin-left: 4px;
  width: 14px;
  height: 14px;
  fill: currentColor;
}

.icon {
  width: 20px;
  height: 20px;
  fill: currentColor;
  transition: fill 0.25s;
}

.menu {
  position: absolute;
  top: calc(var(--tp-nav-height-mobile) / 2 + 20px);
  right: 0;
  opacity: 0;
  visibility: hidden;
  transition: opacity 0.25s, visibility 0.25s, transform 0.25s;
}

@media (min-width: 960px) {
  .menu {
    top: calc(var(--tp-nav-height-desktop) / 2 + 20px);
  }
}
</style>
