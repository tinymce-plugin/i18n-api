<script setup lang="ts">
import { ref } from 'vue'
import { useData } from '/@/config'
import TPIconChevronDown from '../icons/TPIconChevronDown.vue'
import TPIconLanguages from '../icons/TPIconLanguages.vue'
const { locale } = useI18n();
import { getCurrentInstance } from 'vue'
import { useI18n } from 'vue-i18n';
import { useStore } from "/@/stores";
const instance =
  getCurrentInstance().appContext.config.globalProperties.$storage;
const store =useStore()
  function translationChange(lang) {
    instance.locale = { locale: lang };
    locale.value = lang;
      store.chanageLanguage(lang)
}
const { theme } = useData()

const isOpen = ref(false)
 instance.locale = { locale: store.language };
    locale.value = store.language;
function toggle() {
  isOpen.value = !isOpen.value
}
</script>

<template>
  <div v-if="theme.localeLinks" class="TPNavScreenTranslations" :class="{ open: isOpen }">
    <button class="title" @click="toggle">
      <TPIconLanguages class="icon lang" />
      {{ theme.localeLinks.text }}
      <TPIconChevronDown class="icon chevron" />
    </button>

    <ul class="list">
      <li v-for="locale in theme.localeLinks.items" :key="locale.link" class="item">
        <a class="link" :class=" locale.link==store.language? 'active-lang':''" @click="translationChange(locale.link)">{{ locale.text }}</a>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.TPNavScreenTranslations {
  height: 24px;
  width: 100%;
  overflow: hidden;

}

.TPNavScreenTranslations.open {
  height: auto;
}

.title {
  display: flex;
  align-items: center;
  font-size: 14px;
  font-weight: 500;
  background-color: transparent;
  outline: none;
  border: none;
  color: var(--tp-c-text-1);
}

.icon {
  width: 16px;
  height: 16px;
  fill: currentColor;
}

.icon.lang {
  margin-right: 8px;
}

.icon.chevron {
  margin-left: 4px;
}

.list {
  padding: 4px 0 0 24px;
  list-style: none;
}

.link {
  line-height: 32px;
  font-size: 13px;
  text-decoration: none;
  color: var(--tp-c-text-1);
}
</style>
