<script lang="ts" setup>
import { DefaultTheme } from '../config'
import TPNavScreenMenuGroupLink from './TPNavScreenMenuGroupLink.vue'

defineProps<{
  text?: string
  items: DefaultTheme.NavItemWithLink[]
}>()
</script>

<template>
  <div class="TPNavScreenMenuGroupSection">
    <p v-if="text" class="title">{{ text }}</p>
    <TPNavScreenMenuGroupLink
      v-for="item in items"
      :key="item.text"
      :text="item.text"
      :link="item.link"
    />
  </div>
</template>

<style scoped>
.TPNavScreenMenuGroupSection {
  display: block;
}

.title {
  line-height: 32px;
  font-size: 13px;
  font-weight: 700;
  color: var(--tp-c-text-2);
  transition: color 0.25s;
}
</style>
