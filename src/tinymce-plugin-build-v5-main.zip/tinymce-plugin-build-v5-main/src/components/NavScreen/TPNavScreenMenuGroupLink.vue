<script lang="ts" setup>
import { inject } from 'vue'
import TPLink from '../Menu/TPLink.vue'

defineProps<{
  text: string
  link: string
}>()

const closeScreen = inject('close-screen') as () => void
</script>

<template>
  <TPLink class="TPNavScreenMenuGroupLink" :href="link" @click="closeScreen">
    {{ text }}
  </TPLink>
</template>

<style scoped>
.TPNavScreenMenuGroupLink {
  display: block;
  line-height: 32px;
  font-size: 13px;
  font-weight: 400;
  color: var(--tp-c-text-1);
  transition: color 0.25s;
  margin-left: 12px;
}

.TPNavScreenMenuGroupLink:hover {
  color: var(--tp-c-brand);
}
</style>
