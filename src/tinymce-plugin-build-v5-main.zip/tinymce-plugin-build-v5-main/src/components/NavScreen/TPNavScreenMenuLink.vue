<script lang="ts" setup>
import { inject } from 'vue'
import TPLink from '../Menu/TPLink.vue'

defineProps<{
  text: string
  link: string
}>()

const closeScreen = inject('close-screen') as () => void
</script>

<template>
  <TPLink class="TPNavScreenMenuLink" :href="link" @click="closeScreen">
    {{ text }}
  </TPLink>
</template>

<style scoped>
.TPNavScreenMenuLink {
  display: block;
  border-bottom: 1px solid var(--tp-c-divider-light);
  padding: 12px 0 11px;
  line-height: 24px;
  font-size: 14px;
  font-weight: 500;
  color: var(--tp-c-text-1);
  transition: border-color 0.5s, color 0.25s;
}

.TPNavScreenMenuLink:hover {
  color: var(--tp-c-brand);
}
</style>
