<script lang="ts" setup>
import { useData } from '/@/config'
import TPSocialLinks from '../SocialLinks/TPSocialLinks.vue'

const { theme } = useData()
</script>

<template>
  <TPSocialLinks
    v-if="theme.socialLinks"
    class="TPNavScreenSocialLinks"
    :links="theme.socialLinks"
  />
</template>
