<script lang="ts" setup>
import { useData } from '/@/config'
import TPSwitchAppearance from '../Appearance/TPSwitchAppearance.vue'

const { site } = useData()
</script>

<template>
  <div v-if="site.appearance" class="TPNavScreenAppearance">
    <p class="text">Appearance</p>
    <TPSwitchAppearance />
  </div>
</template>

<style scoped>
.TPNavScreenAppearance {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 8px;
  padding: 12px 14px 12px 16px;
  background-color: var(--tp-c-bg-soft);
  transition: background-color 0.5s;
}

.text {
  line-height: 24px;
  font-size: 12px;
  font-weight: 500;
  color: var(--tp-c-text-2);
  transition: color 0.5s;
}
</style>
