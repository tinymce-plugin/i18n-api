<script lang="ts" setup>
import { useData } from '/@/config'
import TPNavScreenMenuLink from './TPNavScreenMenuLink.vue'
import TPNavScreenMenuGroup from './TPNavScreenMenuGroup.vue'

const { theme } = useData()
</script>

<template>
  <nav v-if="theme.nav" class="TPNavScreenMenu">
    <template v-for="item in theme.nav" :key="item.text">
      <TPNavScreenMenuLink
        v-if="'link' in item"
        :text="item.text"
        :link="item.link"
      />
      <TPNavScreenMenuGroup
        v-else
        :text="item.text || ''"
        :items="item.items"
      />
    </template>
  </nav>
</template>
