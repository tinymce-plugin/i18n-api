<script setup lang="ts">
import { ref } from 'vue'
import { disableBodyScroll, clearAllBodyScrollLocks } from 'body-scroll-lock'
// import TPNavScreenMenu from './TPNavScreenMenu.vue'
import TPNavScreenAppearance from './TPNavScreenAppearance.vue'
import TPNavScreenTranslations from './TPNavScreenTranslations.vue'
import TPNavScreenSocialLinks from './TPNavScreenSocialLinks.vue'

defineProps<{
  open: boolean
}>()

const screen = ref<HTMLElement | null>(null)

function lockBodyScroll() {
  disableBodyScroll(screen.value!, { reserveScrollBarGap: true })
}

function unlockBodyScroll() {
  clearAllBodyScrollLocks()
}
</script>

<template>
  <transition
    name="fade"
    @enter="lockBodyScroll"
    @after-leave="unlockBodyScroll"
  >
    <div v-if="open" class="TPNavScreen" ref="screen">
      <div class="container">
        <!-- <TPNavScreenMenu class="menu" /> -->
        <TPNavScreenTranslations class="translations" />
        <TPNavScreenAppearance class="appearance" />
        <TPNavScreenSocialLinks class="social-links" />
      </div>
    </div>
  </transition>
</template>

<style scoped>
.IsFixed .TPNavScreen{
   top: 86px
}
.TPNavScreen {
  position: fixed;
  top: 152px;
  right: 0;
  bottom: 0;
  left: 0;
  /* padding: 0 32px; */
  width: 100%;
  background-color: var(--tp-c-bg);
  overflow-y: auto;
  z-index: 9999;
  transition: background-color 0.5s;
}

.TPNavScreen.fade-enter-active,
.TPNavScreen.fade-leave-active {
  transition: opacity 0.25s;
}

.TPNavScreen.fade-enter-active .container,
.TPNavScreen.fade-leave-active .container {
  transition: transform 0.25s ease;
}

.TPNavScreen.fade-enter-from,
.TPNavScreen.fade-leave-to {
  opacity: 0;
}

.TPNavScreen.fade-enter-from .container,
.TPNavScreen.fade-leave-to .container {
  transform: translateY(-8px);
}

@media (min-width: 768px) {
  .TPNavScreen {
    display: none;
  }
}

.container {
  margin: 0 auto;
  padding: 24px 0 96px;
  max-width: 288px;
}

.menu + .translations,
.menu + .appearance,
.translations + .appearance {
  margin-top: 24px;
}

.menu + .social-links {
  margin-top: 16px;
}

.appearance + .social-links {
  margin-top: 16px;
}
</style>
