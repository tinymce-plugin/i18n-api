## 反馈
---
:::tip 提示
有任何问题，想法，或好的建议，可以在 [*_**Discussions**_*](https://github.com/tinymce-plugin/tinymce-plugin/discussions)。 您也可以在[*_**issues**_*](https://github.com/tinymce-plugin/tinymce-plugin/issues)查看别人提的问题和给出解决方案。
:::

## 支持
---
如果您觉得这个项目对您有帮助，您可以给社区开发团队提供经济支持，使得社区更好的发展

![微信收款码](/assets/images/wxcode.png)![支付宝收款码](/assets/images/zfbcode.png)

## QQ 交流群
---
[*_**`qq交流群 143085779`**_*](https://jq.qq.com/?_wv=1027&k=JgsnIlUw)
![qq群二维码](https://tinymce-plugin.github.io/qq.png#pic_center)
<PagesRouter pagesName="supportandfeedback" />