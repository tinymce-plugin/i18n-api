## next 计划

### 下一步插件开发计划
🚀 表示已经实现的功能
👷 表示进行中的功能
⏳ 表示规划中的功能
💡 想法
📝 计划

 - [👷] tpTabs 

 - [👷] tpCollapse

 - [👷] tpButtons

 - [👷] tpColumns

 - [⏳] tpIconfont

 - [⏳] tpParagraph

### 集成

- [👷] 支持 tinymce-plugin 的 tinymce-vue

- [⏳] 支持 tinymce-plugin 的 tinymce-react


### 版本升级计划

- [📝] 将插件升级支持 tinymce6.0


<PagesRouter pagesName="nextplainfo" />