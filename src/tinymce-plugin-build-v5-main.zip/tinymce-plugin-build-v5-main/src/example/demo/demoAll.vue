<template>
<div >
   <iframe id="demoIframeID" class="demoIframeBox" name="demoIframeID" src="/tinymce/indexall.html" frameborder="0" scrolling="no" width="100%" onload="autoIframeHeight(this)"></iframe>
   <PagesRouter pagesName="demoall" />
</div>
</template>

<script>
export default {
  name: 'DemoAllIframe'
}
</script>

<style  scoped>
.demoIframeBox{
  background: #fff;
}
</style>