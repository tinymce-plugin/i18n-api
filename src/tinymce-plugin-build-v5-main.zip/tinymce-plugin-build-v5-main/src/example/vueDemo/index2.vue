<template>
<div>
    <div class="vueDemo2" >
      <tinymce-vue  v-model="content2" :init="vueDemoOpt2" ></tinymce-vue>
    </div>
    <h1>展示显示2</h1>
    <div v-html="content2"></div>
    <!-- <h1>插件demo展示区域</h1>
    <div class="vueDemo">
      <tinymce-vue v-model="content" :init="vueDemoOpt"  ></tinymce-vue>
    </div>
    <h1>展示显示</h1>
    <div v-html="content"></div> -->
     
       <!-- <button @click="important()"></button> -->
    <PagesRouter pagesName="vuedemo2" />
</div>
</template>

<script>
// import tinymce from "../../assets/lib/tinymce-vue/tinymce";
// // import tp$ from "convertapi/tinymce-plugin/index";
// import tinymcePlugin from "@npkg/tinymce-plugin";
// import tinymcePlugin from "@npkg/tinymce-plugin";
import "../../../public/tinymce/skins/ui/oxide/skin.min.css";
// import "tinymce/skins/ui/oxide/ui/default/skin.css";
import "tinymce/skins/ui/oxide/content.min.css"
import tinymce from "tinymce";
import "@npkg/tinymce-plugin";
import "tinymce/themes/silver/theme.js";
import "tinymce/icons/default/icons.js";
import TinymceVue  from "../../assets/lib/TinymceVue";

// import "tinymce/langs/zh_CN.js";
import "tinymce/plugins/table/plugin.js";
import "tinymce/plugins/link/plugin.js";
import "tinymce/plugins/image/plugin.js";
import "tinymce/plugins/code/plugin.js";
import "tinymce/plugins/fullscreen/plugin.js";
import "tinymce/plugins/media/plugin.js";
import "tinymce/plugins/hr/plugin.js";
// import "tinymce/plugins/list/plugin.js";
import "tinymce/plugins/lists/plugin.js";
import "tinymce/plugins/advlist/plugin.js";
import "tinymce/plugins/anchor/plugin.js";
import "tinymce/plugins/charmap/plugin.js";
import "tinymce/plugins/print/plugin.js";
import "tinymce/plugins/preview/plugin.js";
import "tinymce/plugins/searchreplace/plugin.js";
import "tinymce/plugins/wordcount/plugin.js";
import "tinymce/plugins/visualblocks/plugin.js";
import "tinymce/plugins/visualchars/plugin.js";
import "tinymce/plugins/nonbreaking/plugin.js";
import "tinymce/plugins/fullpage/plugin.js";
import "tinymce/plugins/template/plugin.js";
import "tinymce/plugins/contextmenu/plugin.js";
import "tinymce/plugins/paste/plugin.js";
import "tinymce/plugins/textcolor/plugin.js";
import "tinymce/plugins/colorpicker/plugin.js";
import "tinymce/plugins/textpattern/plugin.js";
import "tinymce/plugins/codesample/plugin.js";
import "tinymce/plugins/toc/plugin.js";
import "tinymce/plugins/autoresize/plugin.js";
import "tinymce/plugins/autolink/plugin.js";

import "@npkg/tinymce-plugin/langs/zh_CN.js";
import "@npkg/tinymce-plugin/tpIndent2em";
import "@npkg/tinymce-plugin/tpImportword";
import "@npkg/tinymce-plugin/tpLetterspacing";
// import tinymcePlugin from "../../assets/lib/tinymce-vue/tinymce-plugin/tinymce-plugin";
// import TinymceVue from "/@/example/vueDemo/Tinymce-vue.vue";
// import "../../../public/tinymce/langs/tp-zh_CN"
// import "../../../public/tinymce/plugins/tpCollapse";
// import "../../../public/tinymce/plugins/tpIconlists/tpIconlists.css"
// import '../../../public/tinymce/css/iconfont.css'
// import "../../../public/tinymce/plugins/tpTabs/tpTabs.css"


export default{
  components: { TinymceVue },
    name: 'vueDemo2',
    data(){
        return {
           editor: '',
           content: 'dsdsdsdsd',
           content2: ``,
           vueDemoOpt: '',
            vueDemoOpt2:{
                // custom_elements: 'tp-collapse',
                min_height: 200,
                max_height: 700,
                skeletonScreen: true,
                external_plugins: {
                   tpCollapse: "/tinymce/plugins/tpCollapse/plugin.js",
                   tpTabs: "/tinymce/plugins/tpTabs/plugin.js",
                   tpButtons: "/tinymce/plugins/tpButtons/plugin.js",
                   tpIconlists: "/tinymce/plugins/tpIconlists/plugin.js",
                   tpParagraph: "/tinymce/plugins/tpParagraph/plugin.js",
                   tpIconfont: "/tinymce/plugins/tpIconfont/plugin.js",
                   tpColumns:  "/tinymce/plugins/tpColumns/plugin.js", 
                //    tpLetterspacing: "/tinymce/plugins/tpLetterspacing/plugin.js",
                   extendgroups: "/tinymce/plugins/extendgroups/plugin.js",
                },
                extend_groups_addicon:{
                    mygroupsicon: '<img  src="https://avatars.githubusercontent.com/u/87648636?s=60&v=4" style="width:20px;" >'
                 },
                extend_groups: {
                    mygroups: {
                        icon: 'mygroupsicon',
                        tooltip: 'mygroupsicon',
                        isSelect: true,
                        type: 'togglemenuitem',
                        items: [
                          {
                            type: 'selectItem',
                            text: '字体',
                            value: '12px 14px 16px 18px 24px 36px 48px 56px 72px',
                            default: '16px',
                            styleSelector: 'font-size',
                            onAction: function(editor, value){
                               editor.formatter.apply('fontsize', { value: value });
                            }
                          },
                          {
                            icon: 'underline',
                            text: '下划线',
                            value: 'underline',
                            styleSelector: 'text-decoration'
                          },
                          {
                            icon: 'bold',
                            text: '加粗',
                            value: 'bold',
                            selector: 'strong'
                          },
                          {
                            icon: 'italic',
                            text: '斜体',
                            value: 'italic',
                            selector: 'em'
                          },
                          ]
                          
                    }
                },
                // base_url:'/tinymce',
                language: 'zh_CN',
                plugins: 'code  tpIndent2em tpLetterspacing autoresize  lists advlist tpImportword   preview',
                toolbar: ['code formatselect fontselect  fontsizeselect  forecolor backcolor bold italic underline strikethrough tpIndent2em tpLetterspacing tpImportword  tpCollapse  mygroups Preview'],
             
        }
     }
       
    },
  methods:{
     important(){
tinyMCE.activeEditor.execCommand('mceImportword')
     },
      init(){
        let that = this;

        that.vueDemoOpt = {
            //   base_url:'/tinymce',
                 toolbar_groups: {
                        formatting: {
                            text: '文字格式',
                            tooltip: 'Formatting',
                            items: 'bold italic underline | superscript subscript',
                        },
                        alignment: {
                            icon: 'align-left',
                            tooltip: 'alignment',
                            items: 'alignleft aligncenter alignright alignjustify',
                        }
                 },
                 extend_groups_addicon:{
                    mygroupsicon: '<img  src="https://avatars.githubusercontent.com/u/87648636?s=60&v=4" style="width:20px;" >'
                 },
                extend_groups: {
                    mygroups: {
                        icon: 'mygroupsicon',
                        tooltip: 'mygroupsicon',
                        isSelect: true,
                        type: 'togglemenuitem',
                        items: [
                          {
                            type: 'selectItem',
                            text: '字体',
                            value: '12px 14px 16px 18px 24px 36px 48px 56px 72px',
                            default: '16px',
                            styleSelector: 'font-size',
                            onAction: function(editor, value){
                               editor.formatter.apply('fontsize', { value: value });
                            }
                          },
                          {
                            icon: 'underline',
                            text: '下划线',
                            value: 'underline',
                            styleSelector: 'text-decoration'
                          },
                          {
                            icon: 'bold',
                            text: '加粗',
                            value: 'bold',
                            selector: 'strong'
                          },
                          {
                            icon: 'italic',
                            text: '斜体',
                            value: 'italic',
                            selector: 'em'
                          },
                          ]
                          
                    }
                },
                plugins:  'print  preview extendgroups clearhtml searchreplace  insertdatetime autolink layout fullscreen line-height image imagetools media upfile link   autosave code  table  advlist lists checklist hr emoticons autosave bdmap indent2em   axupimgs  letterspacing  quickbars attachment wordcount template  autoresize importword searchreplace pagebreak pageembed  tpCollapse tpTabs tpButtons tpIconlists',
                toolbar: ['code formatselect fontselect  fontsizeselect   forecolor backcolor bold italic underline strikethrough link alignment alignmentdrop undo redo  restoredraft layout upfile importword hr lineheight letterspacing line-height indent2em table bdmap image media attachment outdent indent blockquote subscript superscript  emoticons mygroups  preview searchreplace', 'pagebreak template pageembed bullist numlist checklist tpCollapse tpTabs tpButtons tpIconlists'],
                branding: false,
                menubar: false,
               
                language:'zh_CN',
                schema: 'html5',
                min_height:400,
                max_height: 700,
                template_replace_values: {
                    username: 'Jack Black',
                    staffid: '991234',
                    inboth_username: 'Famous Person',
                    inboth_staffid: '2213',
                },
                template_preview_replace_values: {
                    preview_username: 'Jack Black',
                    preview_staffid: '991234',
                    inboth_username: 'Famous Person',
                    inboth_staffid: '2213',
                },
                templates : [
                    {
                    title: 'Date modified example',
                    description: 'Adds a timestamp indicating the last time the document modified.',
                    content: '<p>Last Modified: <time class="mdate">This will be replaced with the date modified.</time></p>'
                    },
                    {
                    title: 'Replace values example',
                    description: 'These values will be replaced when the template is inserted into the editor content.',
                    content: '<p>Name: {$username}, StaffID: {$staffid}</p>'
                    },
                    {
                    title: 'Replace values preview example',
                    description: 'These values are replaced in the preview, but not when inserted into the editor content.',
                    content: '<p>Name: {$preview_username}, StaffID: {$preview_staffid}</p>'
                    },
                    {
                    title: 'Replace values preview and content example',
                    description: 'These values are replaced in the preview, and in the content.',
                    content: '<p>Name: {$inboth_username}, StaffID: {$inboth_staffid}</p>'
                    }
                ],
                table_default_attributes: {
                    'border': '1'
                },
                table_default_styles: {
                    'border-collapse': 'collapse',
                    'width': '100%'
                },
                table_header_type: 'sectionCells',
                table_responsive_width: true,
                skeletonScreen: true,
                images_upload_handler: function (blobInfo, succFun, failFun, progressCallback) {//自定义插入图片函数  blobInfo: 本地图片blob对象, succFun(url|string)： 成功回调（插入图片链接到文本中）, failFun(string)：失败回调
                    var file = blobInfo.blob();
                    var reader = new FileReader();
                    var _result=''
                    reader.onload = function(e){
                        _result = e.target.result
                    }
                    
                     var data = new FormData();
                     data.append("file", file);
                     that.$http({
                        data: data,
                        type: 'GET',
                        url: '/tinymce/api/file.json',
                        header:{'Content-Type':'multipart/form-data'},
                        //  xhr: that.xhrOnProgress(function (e) {
                        //         const percent = (e.loaded / e.total * 100 | 0) + '%';//计算百分比
                        //         progressCallback(percent);
                        // })
                        onUploadProgress (progress){
                           
                            progressCallback(progress+'%')
                        },
                    }).then(function (res) {
                          
                        if ( res.code== 200) {
                             succFun(_result)
                            
                        } else {
                           failFun('上传失败:' + data.data);
                        }
                    }).catch(function (error) {
                        failFun('上传失败:' + error.message)
                    });
                   
                   reader.readAsDataURL(file)
                 },
                  file_picker_callback: function (succFun, value, meta) { //自定义文件上传函数 
                    var filetype = '.pdf, .txt, .zip, .rar, .7z, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .mp3, .mp4';
                    var input = document.createElement('input');
                    input.setAttribute('type', 'file');
                    input.setAttribute('accept', filetype);
                    input.click();
                    input.onchange = function () {
                        var file = this.files[0];
                        var data = new FormData();
                         data.append("file", file);
                         that.$http.get({
                            data: data, 
                            url: './api/file.json', 
                            header:{'Content-Type':'multipart/form-data'},
                            xhr: that.xhrOnProgress(function (e) {
                                const percent = (e.loaded / e.total * 100 | 0) + '%';//计算百分比
                                progressCallback(percent);
                            }),
                         }).then(res=>{
                            succFun(res.data,{ text: res.data });
                         }).catch(function(error){
                            failFun('上传失败:' + error.message)
                         })
                    }
                 },
                 file_callback: function (file, succFun) { //文件上传  file:文件对象 succFun(url|string,obj) 成功回调
                    var data = new FormData();
                    data.append("file", file);
                    console.log(file)
                    that.$http({
                        data: data,
                        type: 'GET',
                        url: '/tinymce/api/file.json',
                        header:{'Content-Type':'multipart/form-data'},
                    }).then(function (res) {
                        console.log(res)
                        if ( res.code== 200) {
                            succFun(res.data,{text: file.name});
                        } 
                    }).catch(function (error) {
                        // failFun('上传失败:' + error.message)
                    });
                 },
                 tp_attachment_assets_path: './plugins/attachment/icons',
                 tp_attachment_icons_path: 'https://unpkg.com/@npkg/tinymce-plugins/plugins/attachment/icons',
                 tp_attachment_upload_handler: function (file, succFun, failFun, progressCallback) {
                    var data = new FormData();
                    data.append("file", file);
                    that.$http({
                        data: data,
                        type: 'GET',
                        url: '/tinymce/api/file.json',
                        header:{'Content-Type':'multipart/form-data'},
                         xhr: that.xhrOnProgress(function (e) {
                                const percent = (e.loaded / e.total * 100 | 0) + '%';//计算百分比
                                progressCallback(percent);
                        })
                        // onUploadProgress (progress){
                        //     progressCallback(progress+'%')
                        // },
                    }).then(function (data) {
                        // console.log(data)
                        if ( data.code== 200) {
                            succFun(data.data);
                        } else {
                           failFun('上传失败:' + data.data);
                        }
                    }).catch(function (error) {
                        failFun('上传失败:' + error.message)
                    });
                },
                 attachment_max_size: 5009715200,
           }
      }

      
  },
  created(){
        this.init()
  }
}
</script>
<style lang="scss" scoped>
 .iframeLayout{
     .iframeLayout_margin{
         border: 1px dashed #333;
         background: #F9CC9D;
         position: relative;
         margin: 0;
         padding: 0;
         font-size: 0;
         .iframeLayout_border{
            //  min-height: 120px;
             margin: 39px ;
             background: #FDDD9B;
             border: 1px solid #333;
             position: relative;
             .iframeLayout_padding{
                margin: 39px ;
                background: rgb(195,208,139);
                border: 1px  dashed #333;
                position: relative;
                .iframeLayout_size{
                    min-height: 40px;
                    position: relative;
                    text-align: center;
                    line-height: 40px;
                    margin: 39px;
                     border: 1px solid #333;
                     span{
                         font-size: 20px;
                         color: #666;
                          display: inline-block;
                          vertical-align: middle;
                        //  line-height: 40px;
                     }
                    input{
                        position: relative;
                        display: inline-block;
                        vertical-align: middle;
                    }
                }
             }
         }
         label{
             font-size: 20px;
             color: #000;
             position: absolute;
             top:2px;
             left: 2px;
         }
         
         input{
             position: absolute;
             width: 31px;
             height: 31px;
             display: block;
              margin: 0 auto;
             text-align: center;
             line-height: 31px;
             font-size: 12px;
             border: 1px solid #ccc;
             background: #fff;
             border-radius:3px;
             overflow: hidden;
             padding: 1px;
            //  background: transparent;
             &:focus{
                 outline:none;
                 border-color: #1f81c3;
             }
         }
         .iframeLayout_top{
             top: 2px;
             left: 50%;
             transform: translateX(-50%);
         }
         .iframeLayout_right{
             top: 50%;
             right: 2px;
             transform: translateY(-50%);
         }
         .iframeLayout_bottom{
             bottom: 2px;
             left: 50%;
             transform: translateX(-50%);
         }
         .iframeLayout_left{
             top: 50%;
             left: 2px;
             transform: translateY(-50%);
         }

     }
 }
</style>