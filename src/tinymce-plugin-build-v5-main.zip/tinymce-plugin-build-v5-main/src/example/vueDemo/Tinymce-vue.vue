<template>
 <!-- <input type="button" @click="importantFn" value="928392893" /> -->
<div>
     <div class="tinymceVue-Box">
        <div class="tinymceVue" :style="{'min-height': '200px'}" >
            <div :id="tinymceID"></div>
            <!-- <div class="skt" :class="'skt-'+tinymce_loading" > 
                <div class="skt-tox-tinymce"  :style="{top: '230px',height: sktData.height/4+'px'}" >
                <div class="skt-tox-editor-container">
                    <div class="skt-tox-editor-header">
                <div  class="skt-tox-menubar">
                    <button  class="skt-tox-mbtn skt-tox-mbtn--select"  v-for="(item,idx) in sktData.menubar" :key="idx" ><span class="skt-tox-mbtn__select-label skeleton">{{item}}</span></button>
                </div>
                    <div class="skt-tox-toolbar-overlord">
                    <div class="skt-tox-toolbar">
                        <div class="skt-tox-toolbar__group" v-for="(item,idx) in sktData.toolbar" :key="idx">
                            <button v-for="(cItem,cIdx) in item" :key="idx" :class="['skt-tox-tbtn',cItem.isSelect?' skt-tox-tbtn--select skt-tox-tbtn--bespoke':'',splitObj[cItem.name]?'skt-tox-split-button':'']"><span :class="[cItem.isSelect?' skt-tox-tbtn__select-label skt-tox-tbtn--select skt-tox-tbtn--bespoke ':'skt-tox-icon tox-tbtn__icon-wrap', 'skeleton']">4</span><div v-if="cItem.isSelect||splitObj[cItem.name]" class="skt-tox-tbtn__select-chevron skeleton"></div></button>
                        </div>
                    </div>
                    </div>
                    <div class="skt-tox-anchorbar"></div>
                </div>
                <div class="skt-tox-sidebar-wrap-box">
               
                    <p  class="skeleton"> &nbsp; </p>
                    <p class="skeleton" v-for="(item ,idx) in sktData.placeholderList" :key="idx">&nbsp;  </p>
                    <p class="skeleton"> </p>
                </div>
                </div> 
                <div class="skt-tox-statusbar">
                 <div class="skeleton">
                      PP
                  </div> 
                   <span v-if="sktData.branding" class="skeleton" style="margin-left: calc(100% - 120px)">Powered by Five </span>
                 </div>
                </div>
          </div> -->

     </div>
    </div>

</div>
</template>

<script>
// import { createSkt } from "/@/libs/tinymce-plugin/src/core/TinymcePlugin";
// import   "/@/libs/tinymce-plugin/src/style/skt.css";
// import '../../assets/lib/tinymce-vue/plugins/tp-lineheight/plugin'
const defaultOpt =JSON.stringify({
                base_url:'/tinymce',
                // branding: false,
                // language:'zh_CN',
                // menubar: false,
                schema: 'html5',
                plugins: 'code hr',
                table_default_attributes: {
                    'border': '1'
                },
                table_default_styles: {
                    'border-collapse': 'collapse',
                    'width': '100%'
                },
                skeletonScreen: true,
                table_header_type: 'sectionCells',
                table_responsive_width: true,
                file_picker_types: 'file img media',
                fontsize_formats: '12px 14px 16px 18px 24px 36px 48px 56px 72px',
})

const  getSktType =(name)=>{
  return /select$/.test(name)
}
const splitObj = {
 'forecolor':true,
 'backcolor':true,
 tpLetterspacing:true,
 tpIconlists: true,
 tpColumns:true,
 table:true,
}
const menubarObj = {
      title:{
        file: {
            zh_CN: '文件',
            en_US: 'File',
        },
        edit: {
            zh_CN: '编辑',
            en_US: 'Edit',
        },
        view: {
            zh_CN: '视图',
            en_US: 'View',
          },
        insert: {
            zh_CN: '插入',
            en_US: 'Insert',
          },
        format: {
            zh_CN: '格式',
            en_US: 'Format',
          },
        table: {
            zh_CN: '表格',
            en_US: 'Table',
          },
        tools: {
            zh_CN: '工具',
            en_US: 'Tools',
          },
        help: {
            zh_CN: '帮助',
            en_US: 'Help',
          }
      },
      items: {
          code: 'tools',
          spellchecker: 'tools',
          spellcheckerlanguage: 'tools',
          wordcount: 'tools',
          image: 'insert',
          link: 'insert',
          media: 'insert',
          hr: 'insert',
          template: 'insert',
          codesample: 'insert',
          charmap: 'insert',
          inserttable: 'table',
          emoticons:'insert',
          pagebreak: 'insert',
          nonbreaking: 'insert',
          anchor: 'insert',
          toc: 'insert',
          insertdatetime: 'insert',
          bold: 'format',
            italic: 'format',
            underline: 'format',
            strikethrough: 'format',
            blockquote: 'format',
            subscript: 'format',
            superscript: 'format',
            removeformat: 'format',
            formatselect: 'format',
            fontselect: 'format',
            fontsizes: 'format',
            forecolor: 'format',
            backcolor: 'format',
            fontformats: 'format',
            blockformats: 'format',
            codeformat: 'format',
            align: 'format',
            table: 'table',
            lineheight: 'format',
            help: 'help',
         

      }
}
//  tools: { title: 'Tools', items: 'spellchecker spellcheckerlanguage | code wordcount' },
const menubarTitle = {
     file:true,
     view:true,
     edit: true
}

const getToolbarGroups = (toolbar)=>{
           let toolbar_groups = []
            let toolbarList = toolbar.split('|');
            toolbarList.forEach((item,index)=>{
                let toolbarItem = item.split(' ');
                let toolbarGroup = [ ];
                toolbarItem.forEach((cItem,cIdx)=>{
                   cItem&&toolbarGroup.push({isSelect: getSktType(cItem) ,name: cItem})
                  cItem&&menubarObj.items[cItem]&&(menubarTitle[menubarObj.items[cItem]]=true)
                })
                toolbarGroup.length>0&&toolbar_groups.push(toolbarGroup);
            })
        return toolbar_groups
}
const getMenubarGroups = (menubar)=>{
           let menubar_groups = []
            let menubarList = menubar.split('|');
            menubarList.forEach((item,index)=>{
                let menubarItem = item.split(' ');
                let menubarGroup = [ ];
                toolbarItem.forEach((cItem,cIdx)=>{
                   cItem&&menubarGroup.push({isSelect: getSktType(cItem) ,name: cItem})
                })
                menubar_groups.push(menubarGroup);
            })
        return menubar_groups
}
const  createSktFn = (opt)=>{
        // console.log(opt.toolbar);
       let toolbar_groups = []
       if(typeof opt.toolbar === 'string'){
             toolbar_groups = getToolbarGroups(opt.toolbar)
       } else if(Array.isArray(opt.toolbar)){
           opt.toolbar.forEach(ele=>{
             toolbar_groups.push(...getToolbarGroups(ele))
           })
       }
         let menubar_groups =  []
         if(opt.menubar === false ){
          
         }else if(typeof opt.menubar === 'string'){
             menubar_groups = getMenubarGroups(opt.menubar)
          }else{
              for (let key in menubarObj.title) {
                menubarTitle[key]&&menubar_groups.push(menubarObj.title[key][opt.language||'en_US'])
               }
          }
          let height = opt.min_height||opt.height||200
         let placeholderList = []
         let placeholderLen = height-150
         for(let i=0;i<placeholderLen;i+=50)placeholderList.push('1')
       return { toolbar:toolbar_groups,menubar:menubar_groups, branding: opt.branding===false?false:true,placeholderList, height,}
    // formatselect fontselect  fontsizeselect
}


export default {
    name: 'TinymceVue',
    props:{
      modelValue: {
          type: [String,Number],
          default: 'dsd'
      },
      options:{
         type: Object,
         default: {}
      },
    },
    emits:['update:modelValue'],
    data(){
        return {
          tinymceID: 'tinymce-'+ new Date().getTime()+Math.floor(Math.random()*10)+Math.floor(Math.random()*10),
          tinymceTimerID: null,
          tinymce_width: '100%',
          tinymce_height: 400,
          tinymce_loading: 'loading',
          editorFn: '',
          sktData:[],
          splitObj:{}

        }
    },
    computed: {
        value: {
        get() {
            return this.modelValue
        },
        set(value) { 
            this.$emit('update:modelValue', value)
        }
    }
  },
  created(){
      this.splitObj = splitObj
    //   console.log(this.options.toolbar);
        //   this.sktData=createSktFn(this.options)
    //   createSkt({selector: '#'+this.tinymceID})
      setTimeout(()=>{
       if(typeof tinymce === "undefined"){ 
           clearInterval(this.tinymceTimerID)
           throw new Error('tinymce undefined');
        }
      },3000)
     this.tinymceTimerID = setInterval(()=>{
          if(typeof tinymce !== "undefined"){
            this.init()
            clearInterval(this.tinymceTimerID)
          }
     },10)

  },
  methods: {
       importantFn(){
            this.editor.execCommand('mceImportword')
      },
      xhrOnProgress(fun) {
          this.xhrOnProgress.onprogress = fun;
          return function () {
              var xhr = this.createXHR();
              if (typeof xhrOnProgress.onprogress !== 'function')
                  return xhr;
              if (xhrOnProgress.onprogress && xhr.upload) {
                  xhr.upload.onprogress = xhrOnProgress.onprogress;
              }
              return xhr;
          }
        },
       createXHR(){
          if(window.XMLHttpRequest) {
           return new XMLHttpRequest(); //要是支持XMLHttpRequest的则采用XMLHttpRequest生成对象
          }
          else if(window.ActiveXobiect){ //要是支持win的ActiveXobiect则采用ActiveXobiect生成对象。
           return new ActiveXobiect('Microsoft.XMLHTTP');
          }
         return '';
        },
        init(){
          let that = this
         let defaultOptions = JSON.parse(defaultOpt)
          defaultOptions.selector = '#' + that.tinymceID;
          defaultOptions.setup =  (editor)=> {
                  that.editorFn = editor
                  editor.on('init', ()=>{
                        // console.log('init', this.content);
                        // editor.on('keyup input', e=>{ //只在编辑器中打字才会触发
                        //         console.log(editor)
                        // }) 
                        // setTimeout(()=>{
                         that.tinymce_loading = '';
                        // },20)
                         editor.setTpContent(that.value)
                        tinymce.activeEditor.setProgressState(false,50); 
                 
                       
                    });
                    editor.on('setContent', (e)=>{
                        let _Interval = setInterval(()=>{
                        if(typeof editor.getTpContent === "function"){
                            clearInterval(_Interval)
                                that.$emit('update:modelValue',editor.getTpContent());
                            }
                        },200)
                    })
                    editor.on('input  focus focusin click focusout drop ObjectResized keydown paste ExecCommand ObjectSelected', ()=>{
                        that.$emit('update:modelValue',editor.getTpContent());
                    })
                }
             Object.assign(defaultOptions, this.options || {})
             that.tinymce_height = defaultOptions.min_height
        
            tinymce.init(defaultOptions)
        }
  }
}
</script>
<style scoped>

 .tinymceVue{
     position: relative;
 }
  .loading{
    position: relative;
 }
 .tinymce_loading{
     position:absolute;
     top: 0;
     left: 0;
     background: rgba(0,0,0,0.6);
     z-index: 99999;
     opacity: 0;
     pointer-events: none;
     /* transition: all 0.3s; */
     width: 100%;
     height: 100%;
 }
 .loading .tinymce_loading{
     opacity: 1;
 }

</style>
