console.log(tinymce.I18n);
// tinymce.addI18n('zh_CN',{
  
//     "Cancel": "取消sd",
//     })