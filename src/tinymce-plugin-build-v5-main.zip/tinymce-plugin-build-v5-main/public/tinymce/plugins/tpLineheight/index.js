'use strict';
module.exports = require('./plugin.min.js')