
 require('./plugin.min.js');