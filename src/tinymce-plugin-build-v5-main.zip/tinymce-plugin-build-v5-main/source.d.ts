declare module "*.json";
declare module "*.png";
declare module "*.jpg";
declare module "*.md";
declare const React: string;
// declare const process: any
