import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import legacy from '@vitejs/plugin-legacy'
import { createVuedcoPlugin ,createRedirect} from "./build/plugins/doc/index";
import vueJsx from '@vitejs/plugin-vue-jsx'
import {prerenderSpa} from "./build/plugins/prerender-spa";
import path from "path";
import VueI18n from "@intlify/vite-plugin-vue-i18n";
const pathResolve = (pathStr:string) => {
  return path.resolve(__dirname, pathStr);
};
// https://vitejs.dev/config/
export default defineConfig(({ command, mode })=>{
  // createRedirect(__dirname)/
  return {
    server: {
      host: '0.0.0.0',
      port: 8999,
      // 是否开启 https
      https: false,
    },
    resolve:{
      alias:{
        '/@': pathResolve('src'),
        'vue': 'vue/dist/vue.esm-bundler.js',
        '/@tools/': pathResolve('/tools/'),
        'tinymce-plugin-setRoutes': pathResolve('src/router/module/setRoutes'),
        '@npkg/tinymce-plugin': pathResolve('build/plugins/tinymce-plugin'),
        'tinymce-plugin': pathResolve('build/plugins/tinymce-plugin')
      },
      extensions:[ '.mjs', '.js', '.ts', '.jsx', '.tsx', '.json','.md']
    },
    css: {
      postcss:{
          plugins: [
            // 前缀追加
            require('autoprefixer')({
              overrideBrowserslist: [
                'Android 4.1',
                'iOS 7.1',
                'Chrome > 31',
                'ff > 31',
                'ie >= 8',
                '> 1%',
              ],
              grid: true,
            }),
            require('postcss-flexbugs-fixes'),
          ],
      },
      preprocessorOptions: {
        scss: {
          additionalData: ` 
          $fontColor: #333;
          $themeColor: #35495E;
          $themeBrightColor: #43B984;
          `
        }
      }
    },
    build:{
      chunkSizeWarningLimit: 2000,
      minify: true,
      sourcemap: false,
      brotliSize: false,
      // @ts-ignore
      output: {
        assetFileNames: `assets/[name].[ext]`,
      },
      rollupOptions: {
        output: {
            manualChunks: {
              vue: ['vue'],
              pinia: ['pinia'],
              'tinymce': ['tinymce'],
              'tinymce-plugin-routes': ['tinymce-plugin-routes']
            },
            entryFileNames: `assets/[name].js`,
            chunkFileNames: `assets/chunk/[name].js`,
            assetFileNames: `assets/[name].[ext]`
        }
     }
    },
    plugins: [
      createVuedcoPlugin({
        docsPath(root) {
          return  "/build/site/"
        },
        // command: command,
        mode: mode,
        root: path.join(__dirname)
        }),
      vue(), VueI18n({
        runtimeOnly: true,
        compositionOnly: true,
        include: [pathResolve("locales/**")]
      }),vueJsx(),
      legacy({
        targets: ['ie >= 11'],
        polyfills: ['es.promise.finally', 'es/map', 'es/set'],
        modernPolyfills: ['es.promise.finally'],
        additionalLegacyPolyfills: ['regenerator-runtime/runtime']
      }),
      prerenderSpa()
    ],
    define: {
      __INTLIFY_PROD_DEVTOOLS__: false,
      "process.env": {
        routesSuffix: process.env.NODE_ENV === "production" ? '.html':" ",
      }
    }
  }
})