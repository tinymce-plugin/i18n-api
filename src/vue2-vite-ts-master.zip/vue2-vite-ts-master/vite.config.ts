/**
 * ==============================================================
 * 配置项 build/plugins/server 已分离到 config/bootstrap 中独立管理
 * --------------------------------------------------------------
 * 其他配置项都可以在这里添加，详情参考 https://vitejs.dev/config/
 * ==============================================================
 */

import configBootstrap from './config/bootstrap';
import { defineConfig } from 'vite';
import { resolve } from 'path';

export default defineConfig(async config =>
  configBootstrap(
    config,
    {
      envPrefix: 'VITE_',
      resolve: {
        alias: [
          { find: '@/', replacement: `${resolve(__dirname, 'src')}/` },
          { find: '~/', replacement: `${resolve(__dirname, 'src')}/` },
          { find: '~@/', replacement: `${resolve(__dirname, 'config/modules')}/` },
          //===============================================================
          // 只需运行时 => new Vue({render (h) {return h('div', 'Hello')}})
          // 需要编译器 => new Vue({template: '<div>Hello</div>'})
          // --------------------------------------------------------------
          // 注：仅为了支持 vue2 组件编译 template 字符模板, 不需编译器可注释掉
          //--------------------------------------------------------------
          // 较小，需在 .env.production 中配置 NODE_ENV 参数
          //---------------------------------------------------------------
          { find: 'vue', replacement: 'vue/dist/vue.common.js' }
          //---------------------------------------------------------------
          // 文件较大，不需在 .env.production 中配置 NODE_ENV 参数
          //---------------------------------------------------------------
          // { find: 'vue', replacement: 'vue/dist/vue.esm.js' }
          //===============================================================
        ]
      },
      css: {
        preprocessorOptions: {
          scss: { charset: false }
        }
      }
    },
    __dirname
  )
);
