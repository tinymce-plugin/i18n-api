// =========================================================================
// [按需加载组件样式](https://www.npmjs.com/package/vite-plugin-style-import)
// =========================================================================
import { createStyleImportPlugin, AndDesignVueResolve, VantResolve, ElementPlusResolve, NutuiResolve, AntdResolve } from 'vite-plugin-style-import';

export default createStyleImportPlugin({
  resolves: [
    // 已有的解决方案，组件样式按需加载
    AndDesignVueResolve(),
    VantResolve(),
    ElementPlusResolve(),
    NutuiResolve(),
    AntdResolve()
  ],
  libs: [
    // 如果你没有你需要的解决方案，你可以直接定义组件样式
    {
      libraryName: 'element-ui',
      esModule: true,
      resolveStyle: name => {
        // 组件样式按需加载，无需全局引入
        return `theme-chalk/${name}.css`;
      }
    }
  ]
});
