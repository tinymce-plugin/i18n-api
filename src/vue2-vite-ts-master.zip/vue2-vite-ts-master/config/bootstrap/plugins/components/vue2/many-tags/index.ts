/**
 * 允许vue2模板使用多元素插件
 */

export default () => {
  const jsdom = require('jsdom');
  const { JSDOM } = jsdom;
  const formatCode = (code: string) => {
    const dom = new JSDOM(`<!DOCTYPE html>${code}`);
    const it = dom.window.document.body;
    const content = typeof it.content == 'object' ? it.content : it;
    if (content && content.children.length > 1) {
      code = `<dfn style="font-style:normal">${code}</dfn>`;
    }
    return code;
  };
  const vitePlugin = () => {
    return {
      name: 'vite-plugin-vue2-many-tags',
      enforce: 'pre',
      async transform(code: string, id: string) {
        if (!/type=template/.test(id)) {
          return null;
        }
        return formatCode(code);
      }
    };
  };
  return vitePlugin();
};
