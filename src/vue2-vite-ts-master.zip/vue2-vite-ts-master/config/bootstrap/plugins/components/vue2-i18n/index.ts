// ==================================================================
// vite+vue2实现i18n国际化支持SFC独立自定义，相关参考
// ==================================================================
// https://www.npmjs.com/package/@yfwz100/vite-plugin-vue2-i18n
// https://www.npmjs.com/package/@jbeche/vite-vue2-i18n-loader
// https://www.npmjs.com/package/@jonathanleelx/vite-plugin-vue2-i18n
// https://www.npmjs.com/package/@intlify/vite-plugin-vue-i18n
// ==================================================================

export default require('./libs/index.js').createI18nPlugin();
