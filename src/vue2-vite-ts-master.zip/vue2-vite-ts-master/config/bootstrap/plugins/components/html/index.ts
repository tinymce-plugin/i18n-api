/**
 * =========================================================================
 * 扩展插件作用：替换入口 index.html 文件内容
 * =========================================================================
 */

export default (options: viteUserOptions) => {
  const htmlPlugin = () => {
    return {
      name: 'vite-plugin-html:transform',
      transformIndexHtml(html: string) {
        // 解决QQ浏览器不支持ESM某些特性的问题
        const globalThis = `<script>if (typeof globalThis == 'undefined') globalThis = undefined;</script>`;

        html = html.replace(/<title>(.*?)<\/title>/, `<title>${options.envs.VITE_APP_TITLE}</title>\r\n${globalThis}`);

        const script =
          `<script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>` +
          //`<script src="https://cdn.bootcdn.net/ajax/libs/require.js/2.3.6/require.min.js"></script>` +
          `</head>`;

        return html.replace(/<\/head>/, script);
      }
    };
  };

  return htmlPlugin();
};
