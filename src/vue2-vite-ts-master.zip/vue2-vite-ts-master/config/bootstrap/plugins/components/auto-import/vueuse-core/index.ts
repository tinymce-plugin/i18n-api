/**
 * ===========================================================
 * 在这里配置你需要用到的VueUse函数库，模板即可直接使用，无需再导入
 * -----------------------------------------------------------
 * see all functions: https://vueuse.org/functions.html
 * ===========================================================
 */
import type { Arrayable } from '@antfu/utils';
import type Options from 'unplugin-auto-import/types';

// vueUse所有函数库
const vueUseImports: Options.ImportsMap = require('./vueuse-json.js').call(null);

export const vue2Imports: Arrayable<Options.ImportsMap | Options.PresetName> = ['@vue/composition-api', 'pinia', vueUseImports];

export const vue3Imports: Arrayable<Options.ImportsMap | Options.PresetName> = ['vue', 'pinia', 'vue-i18n', 'vue-router', vueUseImports];

export default vueUseImports;
