/**
 * ====================================================================
 * Vite 开发服务器配置选项 see https://cn.vitejs.dev/config/#server-host
 * --------------------------------------------------------------------
 * Author: 曹操<pgcao@qq.com>(https://gitee.com/pgcao) License MIT
 * ====================================================================
 */
import type { ServerOptions } from 'vite';

export default (options: viteUserOptions) => {
  const server: ServerOptions = {
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: options.envs.VITE_APP_API_URL, // 你的后端真实接口URL
        changeOrigin: true,
        rewrite: (path: string) => path.replace(/^\/api/, '')
      }
    }
  };

  if (options.envs.VITE_HTTP_PORT) {
    server.port = options.envs.VITE_HTTP_PORT;
  }

  return server;
};
