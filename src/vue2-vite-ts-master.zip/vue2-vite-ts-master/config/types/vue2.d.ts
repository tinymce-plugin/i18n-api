/// <reference types="vite/client" />
/// <reference types="vite-plugin-pages/client" />
/// <reference types="vite-plugin-vue-layouts/client" />

declare module '~icons/*';
declare module 'lodash';
declare module 'element-ui/lib/locale';

// declare module '*.vue' {
//   import { defineComponent } from '@vue/composition-api';
//   const component: ReturnType<typeof defineComponent>;
//   export default component;
// }

declare module '*.vue' {
  import Vue from 'vue';
  export default Vue;
}

declare module '*.md' {
  import Vue from 'vue';
  export default Vue;
}
