import type { MockMethod } from 'vite-plugin-mock';

// [定义数据类型](http://mockjs.com/examples.html)
const template = {
  // 20条数据
  'data|20': [
    {
      /** IP地址 */
      origin: '@ip',
      /** 名称 */
      address: '@county(true)'
    }
  ]
};

export default [
  {
    url: '/test',
    method: 'get',
    response: () => {
      return {
        code: 0,
        data: template
      };
    }
  }
] as MockMethod[];
