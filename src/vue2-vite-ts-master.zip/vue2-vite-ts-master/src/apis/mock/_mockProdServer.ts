//  mockProdServer.ts 生产环境使用演示数据, 使用此数据浏览器将无实质HTTP请求
import { createProdMockServer } from 'vite-plugin-mock/es/createProdMockServer';

// 逐一手动配置
// import goodsMock from './goods';
// import testMock from './test';
// export const mockModules = [...goodsMock, ...testMock];

// 批量载入配置
const mockModules: Array<string> = [];
const modules = import.meta.globEager('./*.ts');
Object.keys(modules).forEach(key => {
  if (key.includes('/_')) return;
  mockModules.push(...modules[key].default);
});

export function setupProdMockServer() {
  createProdMockServer(mockModules);
}
