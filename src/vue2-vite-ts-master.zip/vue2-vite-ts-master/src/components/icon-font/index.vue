<template>
  <component :is="fontComponent" :name="props.name" :type="props.type" />
</template>

<script setup lang="ts">
import createIconfont from './libs/create-iconfont';

/* 本地阿里font-class格式font图标[可改为你的项目地址]，所有图标均可改变色[用了本地不要重复用下面线上] */
import '@/assets/iconfont/iconfont.css';

/* 线上阿里图标[可改为你的项目地址] */
const fontComponent = createIconfont({
  /* 线上阿里font-class格式font图标[可改为你的项目地址]，所有图标均可改变色[用了线上不要重复用上面本地] */
  // linkUrl: ['//at.alicdn.com/t/font_3332458_sqmqhv0b3z.css'],

  /* 线上阿里Symbol格式svg图标[可改为你的项目地址]，有色图标不可改变色 */
  scriptUrl: ['//at.alicdn.com/t/font_3332458_sqmqhv0b3z.js']
});

const props = withDefaults(
  defineProps<{
    name: string;
    type?: 'font' | 'svg';
  }>(),
  { type: 'font' }
);
</script>
