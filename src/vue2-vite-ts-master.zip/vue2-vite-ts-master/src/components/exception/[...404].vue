<template>
  <div>404 Not Found</div>
</template>
