export const testStore = defineStore('test', {
  state: () => {
    const count = 0;
    return { count, name: 'test' };
  },
  actions: {
    inc() {
      this.name = this.count > 10 ? 'test变化' : 'test';
      this.count++;
    },
    cut() {
      this.count > 0 && this.count--;
    },
    zero() {
      this.count = 0;
    }
  },
  getters: {
    doubleCount(state) {
      return state.count * 2;
    },
    doublePlusOne(): number {
      return this.doubleCount + 1;
    }
  },
  // 开启数据缓存 see https://seb-l.github.io/pinia-plugin-persist/advanced/strategies.html
  persist: {
    enabled: true,
    strategies: [
      {
        paths: ['count']
      }
    ]
  }
});
