import Vue from 'vue';

export default () => {
  const proxy = Vue.prototype;
  console.log('这里可以用 proxy 引用全局变量为所欲为了', proxy);
  return {
    proxy
  };
};
