<template>
  <div style="color: green; font-size: 1.2em" class="p-10">
    本地iconify:
    <icon-svg-github />

    <hr />
    线上iconify:
    <icon-svg-mdi-github />
    <icon-svg-mdi-access-point />

    <hr />
    iconfont 阿里Symbol格式svg图标:
    <icon-font name="icon-pailietubiao-32" type="svg" />
    <icon-font name="icon-erweima" type="svg" />

    <hr />
    iconfont 阿里font-class格式font图标:
    <icon-font name="icon-pailietubiao-32" />
    <icon-font name="icon-erweima" />
  </div>
</template>
