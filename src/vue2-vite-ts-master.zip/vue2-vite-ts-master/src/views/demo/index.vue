<script setup>
import { chunk } from 'lodash';
console.log(chunk(['a', 'b', 'c', 'd'], 2));

const { x, y } = useMouse();
</script>

<template>
  <div class="text-center mt-30 mb-30">
    观看控制台输出结果
    <div>x坐标 {{ x }} y坐标 {{ y }}</div>
  </div>
</template>
