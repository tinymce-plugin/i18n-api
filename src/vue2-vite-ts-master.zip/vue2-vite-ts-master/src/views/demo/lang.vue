<script setup>
const { proxy } = getCurrentInstance();
const langs = ['zh-CN', 'zh-TW', 'en'];
const toggleLocales = () => {
  const theLang = proxy.$i18n.locale;
  const lang = langs[(langs.indexOf(theLang) + 1) % langs.length];
  proxy.setLang(lang);
};
const count = ref(0);
</script>

<template>
  <div style="text-align: center; margin-top: 10%">
    <h1>{{ $t('language') }}</h1>
    {{ $t('hello') }}, {{ $t('hello-parent') }}

    <!-- 当语种含有HTML元素时，使用i18n插槽方式展现 -->
    <i18n path="tips" tag="p" class="@apply lg:text-center mt-4 max-w-2xl text-base text-gray-500 lg:mx-auto">
      <template #dom><strong>Strong</strong></template>
    </i18n>

    <button class="icon-btn mx-2" @click="toggleLocales"><icon-svg-carbon-language /></button>
    <button type="button" @click="count++">count is: {{ count }}</button>
  </div>
</template>

<i18n>
{
  "en": {
    "language": "英语",
    "hello-parent": "I am $the parent language!",
    "tips": "This is a {dom} demo."
  },
  "zh-CN": {
    "language": "中文简体",
    "hello-parent": "我是父层语言！",
    "tips": "这是一个 {dom} 测试."
  },
  "zh-TW": {
    "language": "中文繁体",
    "hello-parent": "我是父層語言！",
    "tips": "這是一個 {dom} 測試."
  }
}
</i18n>
