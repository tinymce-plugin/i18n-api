<script setup>
const { proxy } = getCurrentInstance();
const back = () => proxy.$router.go(-1);
</script>

<template>
  <div class="text-center mt-30">
    这是另一布局页面，点击：
    <button @click="back">👉 Go Home</button>
  </div>
</template>

<route lang="yml">
meta:
  layout: blank
</route>
