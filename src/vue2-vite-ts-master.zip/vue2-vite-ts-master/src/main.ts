/**
 * ======================================================================
 * vue2项目入口[此文件基本不需要进行修改，更多扩展组件插件请在plugins目录统一维护]
 * ----------------------------------------------------------------------
 * Author: 曹操<pgcao@qq.com>(https://gitee.com/pgcao/)
 * ======================================================================
 * see https://cn.vuejs.org/ or https://v2.vuejs.org/
 */
import Vue from 'vue';
import App from '@/App.vue';
import bootstrapPlugins from '@/plugins';

// 是否使用 devTools 工具
// Vue.config.devtools = false;

// 是否保留开发模式警告信息提示
Vue.config.productionTip = false;

// 自动引导装载项目所依赖的第三方组件插件, 放在plugins目录统一维护
void bootstrapPlugins(App, Props => new Vue(Props).$mount('#app'));
