import enLocale from 'element-ui/lib/locale/lang/en';
export default {
  ...enLocale
};
