import zhLocale from 'element-ui/lib/locale/lang/zh-CN';
export default {
  ...zhLocale
};
