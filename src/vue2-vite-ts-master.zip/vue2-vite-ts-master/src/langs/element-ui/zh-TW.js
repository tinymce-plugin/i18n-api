import zhTwLocale from 'element-ui/lib/locale/lang/zh-TW';
export default {
  ...zhTwLocale
};
