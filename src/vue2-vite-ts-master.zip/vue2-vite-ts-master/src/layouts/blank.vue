<template>
  <!-- 无布局 -->
  <div id="app"><RouterView /></div>
</template>
