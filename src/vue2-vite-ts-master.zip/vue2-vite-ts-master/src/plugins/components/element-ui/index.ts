/**
 * ----------------------------------------------------
 * 插件作用：使用饿了么UI人机界面框架(脚手架已支持按需引入)
 * ----------------------------------------------------
 * see https://element.eleme.cn/#/zh-CN
 * ----------------------------------------------------
 */

import type { App } from '@/plugins/types';

/* 全量引入 Element(不推荐) */
// import ElementUI from 'element-ui';
// import 'element-ui/lib/theme-chalk/index.css';
// import { Loading, MessageBox, Message, Notification } from 'element-ui';
// export default (app: App) => {
//   app.use(Loading.directive);
//   app.prototype.$loading = Loading.service;
//   app.prototype.$msgbox = MessageBox;
//   app.prototype.$alert = MessageBox.alert;
//   app.prototype.$confirm = MessageBox.confirm;
//   app.prototype.$prompt = MessageBox.prompt;
//   app.prototype.$notify = Notification;
//   app.prototype.$message = Message;
//   app.use(ElementUI, { size: 'small', zIndex: 3000 })
// }

/* 按需引入 Element(推荐) */
// import { Checkbox } from 'element-ui';
export default (app: App) => {
  // app.use(Checkbox); //表格需要用到，所以要全局注入，凡是存在隐式引入的都要先全局注入
  app.prototype.$ELEMENT = { size: 'small', zIndex: 3000 };
};
