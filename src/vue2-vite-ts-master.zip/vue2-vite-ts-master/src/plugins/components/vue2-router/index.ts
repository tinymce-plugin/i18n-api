/**
 * ----------------------------------------------------
 * 插件功能：从 src/views 目录自动生成文件路由
 * ----------------------------------------------------
 * 更多路由文档 see https://v3.router.vuejs.org/zh/api/
 * ----------------------------------------------------
 */

import type { App } from '@/plugins/types';
import VueRouter from 'vue-router';
import { createRoutes, createGuard } from './guards';

import basicRoutes from 'virtual:generated-pages';
const routes = createRoutes(basicRoutes);

/* @__PURE__ */
import.meta.env.DEBUG && console.log('自动生成的路由组', routes);

const isUseHash = import.meta.env.VITE_HTTP_HASH === true;
const router = new VueRouter({
  base: import.meta.env.VITE_APP_BASE_URL || '/',
  mode: isUseHash ? 'hash' : 'history', //是否使用带#号访问路由
  routes
});

export default async (app: App) => {
  app.use(VueRouter);
  createGuard(router);
  return { router };
};
