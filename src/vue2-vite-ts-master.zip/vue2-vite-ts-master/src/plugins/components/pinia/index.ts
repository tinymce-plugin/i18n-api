/**
 * -------------------------------------------------------
 * 轻量级状态管理库，支持持久化 see https://pinia.vuejs.org/
 * -------------------------------------------------------
 */

import { createPinia, PiniaVuePlugin } from 'pinia';
import piniaPluginPersist from 'pinia-plugin-persist';

export default (app: any) => {
  const pinia = createPinia();
  // [数据持久化插件](https://seb-l.github.io/pinia-plugin-persist/)
  pinia.use(piniaPluginPersist);
  // 同一配置使Pinia兼容vue2 & vue3写法
  if (parseInt(app.version) > 2) {
    return app.use(pinia);
  } else {
    app.use(PiniaVuePlugin);
    return { pinia };
  }
};
