import type { VueConstructor as App } from 'vue';
export { App };
