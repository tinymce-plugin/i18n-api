<template>
  <el-empty>
    <el-button type="primary">Button</el-button>
  </el-empty>
</template>
