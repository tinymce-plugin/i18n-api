<template>
  <svg
    id="图层_1"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 120 120"
    style="enable-background: new 0 0 120 120"
    xml:space="preserve"
  >
    <path
      class="st0"
      d="M8,16h104c1.7,0,3,1.3,3,3v82c0,1.7-1.3,3-3,3H8c-1.7,0-3-1.3-3-3V19C5,17.3,6.3,16,8,16z"
    />
    <path
      class="st1"
      d="M13,22c0,1.1-0.9,2-2,2c-1.1,0-2-0.9-2-2s0.9-2,2-2C12.1,20,13,20.9,13,22z M19,22c0,1.1-0.9,2-2,2s-2-0.9-2-2
    s0.9-2,2-2S19,20.9,19,22z M23,24c1.1,0,2-0.9,2-2s-0.9-2-2-2s-2,0.9-2,2S21.9,24,23,24z"
    />
    <path
      class="st2"
      d="M12,28h96c1.7,0,3,1.3,3,3v66c0,1.7-1.3,3-3,3H12c-1.7,0-3-1.3-3-3V31C9,29.3,10.3,28,12,28z"
    />
    <path
      class="st3"
      d="M39,34h42c1.1,0,2,0.9,2,2v22c0,1.1-0.9,2-2,2H39c-1.1,0-2-0.9-2-2V36C37,34.9,37.9,34,39,34z"
    />
    <path
      class="st4"
      d="M47,38h26c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H47c-1.1,0-2-0.9-2-2l0,0C45,38.9,45.9,38,47,38z"
    />
    <path
      class="st4"
      d="M54,52h12c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H54c-1.1,0-2-0.9-2-2l0,0C52,52.9,52.9,52,54,52z"
    />
    <path
      class="st4"
      d="M43,45h34c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H43c-1.1,0-2-0.9-2-2l0,0C41,45.9,41.9,45,43,45z"
    />
    <path
      class="st5"
      d="M17,75h22c1.1,0,2,0.9,2,2v15c0,1.1-0.9,2-2,2H17c-1.1,0-2-0.9-2-2V77C15,75.9,15.9,75,17,75z"
    />
    <path
      class="st6"
      d="M21,79h14c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H21c-1.1,0-2-0.9-2-2l0,0C19,79.9,19.9,79,21,79z"
    />
    <path
      class="st6"
      d="M24,86h8c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2h-8c-1.1,0-2-0.9-2-2l0,0C22,86.9,22.9,86,24,86z"
    />
    <path
      class="st7"
      d="M49,75h22c1.1,0,2,0.9,2,2v15c0,1.1-0.9,2-2,2H49c-1.1,0-2-0.9-2-2V77C47,75.9,47.9,75,49,75z"
    />
    <path
      class="st8"
      d="M53,79h14c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H53c-1.1,0-2-0.9-2-2l0,0C51,79.9,51.9,79,53,79z"
    />
    <path
      class="st8"
      d="M56,86h8c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2h-8c-1.1,0-2-0.9-2-2l0,0C54,86.9,54.9,86,56,86z"
    />
    <path
      class="st9"
      d="M81,75h22c1.1,0,2,0.9,2,2v15c0,1.1-0.9,2-2,2H81c-1.1,0-2-0.9-2-2V77C79,75.9,79.9,75,81,75z"
    />
    <path
      class="st10"
      d="M85,79h14c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2H85c-1.1,0-2-0.9-2-2l0,0C83,79.9,83.9,79,85,79z"
    />
    <path
      class="st10"
      d="M88,86h8c1.1,0,2,0.9,2,2l0,0c0,1.1-0.9,2-2,2h-8c-1.1,0-2-0.9-2-2l0,0C86,86.9,86.9,86,88,86z"
    />
    <path
      class="st11"
      d="M58,60h4v5h30c1.1,0,2,0.9,2,2v2v6h-4v-6H62v6h-4v-6H30v6h-4v-6v-2c0-1.1,0.9-2,2-2h30V60z"
    />
  </svg>
</template>

<style scoped lang="scss">
.st0 {
  fill: #f2f8fe;
}
.st1 {
  fill-rule: evenodd;
  clip-rule: evenodd;
  fill: #ddeafc;
}
.st2 {
  fill: #ffffff;
}
.st3 {
  fill: #20a0ff;
}
.st4 {
  fill: #0d89e5;
}
.st5 {
  fill: #80a8e1;
}
.st6 {
  fill: #5289d6;
}
.st7 {
  fill: #ffd6d2;
}
.st8 {
  fill: #f8a3a4;
}
.st9 {
  fill: #dbedff;
}
.st10 {
  fill: #a2c6eb;
}
.st11 {
  fill-rule: evenodd;
  clip-rule: evenodd;
  fill: #deebfd;
}

.dark {
  .st0 {
    fill: #272829;
  }
  .st1 {
    fill-rule: evenodd;
    clip-rule: evenodd;
    fill: #494c52;
  }
  .st2 {
    fill: #33383d;
  }
  .st3 {
    fill: #20a0ff;
  }
  .st4 {
    fill: #0d89e5;
  }
  .st5 {
    fill: #80a8e1;
  }
  .st6 {
    fill: #5289d6;
  }
  .st7 {
    fill: #ffd6d2;
  }
  .st8 {
    fill: #f8a3a4;
  }
  .st9 {
    fill: #5d6874;
  }
  .st10 {
    fill: #a2c6eb;
  }
  .st11 {
    fill-rule: evenodd;
    clip-rule: evenodd;
    fill: #3e4652;
  }
}
</style>
