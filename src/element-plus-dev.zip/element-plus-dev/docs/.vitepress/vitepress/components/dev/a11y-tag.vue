<template>
  <el-tag size="small" effect="plain" hit round class="ml-2">a11y</el-tag>
</template>
<style scoped>
.el-tag {
  color: #6222c2;
}
.el-tag.is-hit {
  border-color: #9065db;
}
.dark .el-tag {
  color: #9065db;
}
.dark .el-tag.is-hit {
  border-color: #6222c2;
}
</style>
