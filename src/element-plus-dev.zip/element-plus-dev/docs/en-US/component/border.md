---
title: Border
lang: en-US
---

# Border

We standardize the borders that can be used in buttons, cards, pop-ups and other components.

## Border style

There are few border styles to choose.

:::demo

border/border

:::

## Radius

There are few radius styles to choose.

:::demo

border/radius

:::

## Shadow

There are few shadow styles to choose.

:::demo

border/shadow

:::
