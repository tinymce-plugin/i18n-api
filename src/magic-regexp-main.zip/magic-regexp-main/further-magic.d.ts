// Legacy stub for previous TS versions

export * from './dist/further-magic'
