<template>
  <div class="font-bold flex flex-row items-center gap-2">🦄 magic-regexp</div>
</template>
