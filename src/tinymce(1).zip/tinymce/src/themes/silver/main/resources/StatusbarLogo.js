import Logo from './statusbar-logo.svg';

export { Logo };
