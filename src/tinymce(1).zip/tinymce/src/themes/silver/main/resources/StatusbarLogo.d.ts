export const Logo: string;
