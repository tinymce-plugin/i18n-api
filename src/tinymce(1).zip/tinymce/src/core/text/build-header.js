/**
 * TinyMCE version @@version@@ (@@releaseDate@@)
 */
